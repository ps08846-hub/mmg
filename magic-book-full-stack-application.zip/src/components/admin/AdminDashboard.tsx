"use client";

import React, { useState, useEffect } from "react";
import { VideoItem, CategoryItem, AdminUser } from "@/types";
import {
  ShieldAlert,
  Lock,
  Upload,
  Film,
  Plus,
  Trash2,
  Edit,
  Eye,
  LogOut,
  FolderOpen,
  CheckCircle,
  AlertCircle,
  HardDrive,
  BarChart3,
  BookOpen,
  ArrowLeft,
  Sparkles,
  Link,
  Layers,
} from "lucide-react";

interface AdminDashboardProps {
  onClose: () => void;
  categories: CategoryItem[];
  onRefreshData: () => Promise<void>;
}

// Preset test open-source video URLs for convenience
const PRESET_DEMO_VIDEOS = [
  {
    title: "Blender - Cosmos Laundromat",
    url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4",
    thumb: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&q=80",
    duration: "12:10",
    type: "short",
  },
  {
    title: "Subaru Outback - Mountain Journey",
    url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnStreetAndDirt.mp4",
    thumb: "https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=800&q=80",
    duration: "9:50",
    type: "documentary",
  },
];

export function AdminDashboard({
  onClose,
  categories,
  onRefreshData,
}: AdminDashboardProps) {
  const [currentUser, setCurrentUser] = useState<AdminUser | null>(null);
  const [isCheckingAuth, setIsCheckingAuth] = useState(true);

  // Login form state
  const [email, setEmail] = useState("admin@magicbook.com");
  const [password, setPassword] = useState("MagicBook2025!");
  const [loginError, setLoginError] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Admin view tab
  const [activeTab, setActiveTab] = useState<"videos" | "upload" | "storage" | "categories">("videos");

  // Video list state
  const [videosList, setVideosList] = useState<VideoItem[]>([]);
  const [isLoadingVideos, setIsLoadingVideos] = useState(false);

  // Stats state
  const [stats, setStats] = useState<{
    totalVideos: number;
    publishedVideos: number;
    draftVideos: number;
    totalNotes: number;
    totalCategories: number;
    totalViews: number;
  } | null>(null);

  // Video Form state
  const [videoForm, setVideoForm] = useState({
    title: "",
    description: "",
    categoryId: categories[0]?.id || 1,
    videoUrl: "",
    thumbnailUrl: "",
    duration: "10:00",
    videoType: "movie",
    tagsInput: "Cinema, OpenSource",
    isFeatured: false,
    isPublished: true,
    releaseYear: 2025,
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formSuccess, setFormSuccess] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  // Editing Video state
  const [editingVideo, setEditingVideo] = useState<VideoItem | null>(null);

  // New Category state
  const [newCatName, setNewCatName] = useState("");
  const [newCatDesc, setNewCatDesc] = useState("");

  // Check auth on mount
  useEffect(() => {
    checkAdminAuth();
  }, []);

  const checkAdminAuth = async () => {
    try {
      setIsCheckingAuth(true);
      const res = await fetch("/api/admin/me");
      const data = await res.json();
      if (data.success && data.user) {
        setCurrentUser(data.user);
        loadAdminData();
      } else {
        setCurrentUser(null);
      }
    } catch {
      setCurrentUser(null);
    } finally {
      setIsCheckingAuth(false);
    }
  };

  const loadAdminData = async () => {
    setIsLoadingVideos(true);
    try {
      const [vRes, sRes] = await Promise.all([
        fetch("/api/videos?includeUnpublished=true"),
        fetch("/api/admin/stats"),
      ]);
      const vData = await vRes.json();
      const sData = await sRes.json();
      if (vData.success) {
        setVideosList(vData.videos);
      }
      if (sData.success) {
        setStats(sData.stats);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoadingVideos(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setIsLoggingIn(true);
    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (data.success) {
        setCurrentUser(data.user);
        loadAdminData();
      } else {
        setLoginError(data.error || "Login failed");
      }
    } catch {
      setLoginError("Failed to connect to authentication service");
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogout = async () => {
    await fetch("/api/admin/logout", { method: "POST" });
    setCurrentUser(null);
  };

  const handleAddVideo = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setFormSuccess(null);
    setIsSubmitting(true);

    try {
      const tagsArray = videoForm.tagsInput
        .split(",")
        .map((t) => t.trim())
        .filter(Boolean);

      const res = await fetch("/api/videos", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: videoForm.title,
          description: videoForm.description,
          categoryId: videoForm.categoryId,
          videoUrl: videoForm.videoUrl,
          thumbnailUrl: videoForm.thumbnailUrl,
          duration: videoForm.duration,
          videoType: videoForm.videoType,
          tags: tagsArray,
          isFeatured: videoForm.isFeatured,
          isPublished: videoForm.isPublished,
          releaseYear: videoForm.releaseYear,
        }),
      });

      const data = await res.json();
      if (data.success) {
        setFormSuccess("Video successfully added to library!");
        setVideoForm({
          title: "",
          description: "",
          categoryId: categories[0]?.id || 1,
          videoUrl: "",
          thumbnailUrl: "",
          duration: "10:00",
          videoType: "movie",
          tagsInput: "Cinema, OpenSource",
          isFeatured: false,
          isPublished: true,
          releaseYear: 2025,
        });
        loadAdminData();
        await onRefreshData();
      } else {
        setFormError(data.error || "Failed to create video");
      }
    } catch {
      setFormError("Server error during video upload");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleTogglePublish = async (video: VideoItem) => {
    try {
      const res = await fetch(`/api/videos/${video.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isPublished: !video.isPublished }),
      });
      const data = await res.json();
      if (data.success) {
        loadAdminData();
        await onRefreshData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteVideo = async (id: number) => {
    if (!confirm("Are you certain you wish to delete this video reel permanently?")) return;
    try {
      const res = await fetch(`/api/videos/${id}`, { method: "DELETE" });
      const data = await res.json();
      if (data.success) {
        loadAdminData();
        await onRefreshData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleUpdateVideo = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingVideo) return;

    try {
      const res = await fetch(`/api/videos/${editingVideo.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editingVideo),
      });
      const data = await res.json();
      if (data.success) {
        setEditingVideo(null);
        loadAdminData();
        await onRefreshData();
      } else {
        alert(data.error || "Failed to update video");
      }
    } catch (err) {
      console.error(err);
      alert("Failed to update video");
    }
  };

  const handleAddCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;
    try {
      const res = await fetch("/api/categories", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: newCatName.trim(), description: newCatDesc.trim() }),
      });
      const data = await res.json();
      if (data.success) {
        setNewCatName("");
        setNewCatDesc("");
        loadAdminData();
        await onRefreshData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // If loading session
  if (isCheckingAuth) {
    return (
      <div className="fixed inset-0 z-50 bg-[#140f0c] text-[#ede3d5] flex items-center justify-center">
        <div className="text-center space-y-3 font-serif">
          <Sparkles className="w-8 h-8 text-[#d4af37] animate-spin mx-auto" />
          <p>Unlocking Archivist Chamber...</p>
        </div>
      </div>
    );
  }

  // IF NOT AUTHENTICATED: SHOW SECURE LOGIN
  if (!currentUser) {
    return (
      <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md overflow-y-auto p-4 flex items-center justify-center text-[#ede4d8]">
        <div className="w-full max-w-md rounded-3xl bg-[#1d1611] border border-[#523e2e] shadow-2xl p-6 sm:p-8 space-y-5 animate-in fade-in">
          {/* Header */}
          <div className="text-center space-y-2">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#c59c44] to-[#74551f] p-0.5 mx-auto shadow-lg flex items-center justify-center">
              <div className="w-full h-full bg-[#1b130e] rounded-[14px] flex items-center justify-center">
                <Lock className="w-6 h-6 text-[#f5d88f]" />
              </div>
            </div>
            <h2 className="font-serif text-xl font-bold text-[#fcf9f2]">
              Archivist Sanctuary Login
            </h2>
            <p className="text-xs text-[#a89582] font-serif">
              Protected administrator access for Magic Book video libraries
            </p>
          </div>

          {/* Quick Credential Preset Notification */}
          <div className="p-3 rounded-xl bg-[#261c14] border border-[#5b422f] text-[11px] text-[#cfbeab] space-y-1">
            <p className="font-bold text-[#f7dc78]">Demo Admin Credentials:</p>
            <p className="font-mono text-[10px]">Email: admin@magicbook.com</p>
            <p className="font-mono text-[10px]">Password: MagicBook2025!</p>
          </div>

          {loginError && (
            <div className="p-3 rounded-xl bg-rose-950/40 border border-rose-800 text-rose-200 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{loginError}</span>
            </div>
          )}

          {/* Login Form */}
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-serif text-[#bcaaa0] mb-1">
                Admin Email
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="w-full px-3 py-2 rounded-xl bg-[#281e17] border border-[#4d3827] text-xs text-white focus:outline-none focus:border-[#d4af37]"
              />
            </div>

            <div>
              <label className="block text-xs font-serif text-[#bcaaa0] mb-1">
                Security Password
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="w-full px-3 py-2 rounded-xl bg-[#281e17] border border-[#4d3827] text-xs text-white focus:outline-none focus:border-[#d4af37]"
              />
            </div>

            <button
              type="submit"
              disabled={isLoggingIn}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#9b7536] via-[#cf9e42] to-[#9b7536] text-[#160f06] font-serif font-bold text-xs shadow-lg hover:brightness-110 disabled:opacity-50 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>{isLoggingIn ? "Verifying..." : "Enter Chamber"}</span>
            </button>
          </form>

          <button
            onClick={onClose}
            className="w-full text-center text-xs text-[#a6927a] hover:text-[#ede4d8] font-serif pt-1"
          >
            ← Back to Journal
          </button>
        </div>
      </div>
    );
  }

  // AUTHENTICATED ADMIN DASHBOARD
  return (
    <div className="fixed inset-0 z-50 bg-[#120d09] text-[#ede4d8] overflow-y-auto flex flex-col">
      {/* Top Admin Bar */}
      <header className="sticky top-0 z-30 bg-[#1c1510] border-b border-[#433121] px-4 py-3 shrink-0 shadow-md">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg bg-[#281e17] hover:bg-[#34271e] text-stone-300 hover:text-white transition-colors"
              title="Return to App"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>

            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-serif text-base font-bold text-[#fcf9f2]">
                  Archivist Control Room
                </h1>
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 bg-amber-500/20 text-amber-300 rounded-full border border-amber-500/30">
                  Admin Active
                </span>
              </div>
              <p className="text-[11px] text-[#a99887] font-mono">
                {currentUser.name} ({currentUser.email})
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleLogout}
              className="px-3 py-1.5 rounded-xl bg-rose-950/40 hover:bg-rose-950/70 border border-rose-800/60 text-rose-300 text-xs font-serif flex items-center gap-1.5 transition-colors"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Logout</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Admin Content */}
      <main className="flex-1 max-w-6xl w-full mx-auto p-4 space-y-6 pb-20">
        {/* Stats Row */}
        {stats && (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            <div className="p-3.5 rounded-2xl bg-[#1d1611] border border-[#483526]">
              <span className="text-[10px] uppercase font-mono text-[#aa9785]">Total Videos</span>
              <p className="font-serif text-2xl font-bold text-[#fcf9f2]">{stats.totalVideos}</p>
            </div>
            <div className="p-3.5 rounded-2xl bg-[#1d1611] border border-[#483526]">
              <span className="text-[10px] uppercase font-mono text-[#aa9785]">Published</span>
              <p className="font-serif text-2xl font-bold text-emerald-400">{stats.publishedVideos}</p>
            </div>
            <div className="p-3.5 rounded-2xl bg-[#1d1611] border border-[#483526]">
              <span className="text-[10px] uppercase font-mono text-[#aa9785]">Drafts</span>
              <p className="font-serif text-2xl font-bold text-amber-400">{stats.draftVideos}</p>
            </div>
            <div className="p-3.5 rounded-2xl bg-[#1d1611] border border-[#483526]">
              <span className="text-[10px] uppercase font-mono text-[#aa9785]">Total Views</span>
              <p className="font-serif text-2xl font-bold text-[#f7dc78]">{stats.totalViews}</p>
            </div>
            <div className="p-3.5 rounded-2xl bg-[#1d1611] border border-[#483526]">
              <span className="text-[10px] uppercase font-mono text-[#aa9785]">Categories</span>
              <p className="font-serif text-2xl font-bold text-sky-400">{stats.totalCategories}</p>
            </div>
            <div className="p-3.5 rounded-2xl bg-[#1d1611] border border-[#483526]">
              <span className="text-[10px] uppercase font-mono text-[#aa9785]">Total Notes</span>
              <p className="font-serif text-2xl font-bold text-stone-300">{stats.totalNotes}</p>
            </div>
          </div>
        )}

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 border-b border-[#3e2e21] pb-2 overflow-x-auto">
          <button
            onClick={() => setActiveTab("videos")}
            className={`px-4 py-1.5 rounded-xl text-xs font-serif shrink-0 transition-all ${
              activeTab === "videos"
                ? "bg-[#d4af37]/20 border border-[#d4af37]/50 text-[#f7dc78] font-bold"
                : "text-[#aa9785] hover:text-white"
            }`}
          >
            Video Management ({videosList.length})
          </button>
          <button
            onClick={() => setActiveTab("upload")}
            className={`px-4 py-1.5 rounded-xl text-xs font-serif shrink-0 transition-all ${
              activeTab === "upload"
                ? "bg-[#d4af37]/20 border border-[#d4af37]/50 text-[#f7dc78] font-bold"
                : "text-[#aa9785] hover:text-white"
            }`}
          >
            + Upload / Add Video
          </button>
          <button
            onClick={() => setActiveTab("storage")}
            className={`px-4 py-1.5 rounded-xl text-xs font-serif shrink-0 transition-all ${
              activeTab === "storage"
                ? "bg-[#d4af37]/20 border border-[#d4af37]/50 text-[#f7dc78] font-bold"
                : "text-[#aa9785] hover:text-white"
            }`}
          >
            Storage &amp; CDN Setup
          </button>
          <button
            onClick={() => setActiveTab("categories")}
            className={`px-4 py-1.5 rounded-xl text-xs font-serif shrink-0 transition-all ${
              activeTab === "categories"
                ? "bg-[#d4af37]/20 border border-[#d4af37]/50 text-[#f7dc78] font-bold"
                : "text-[#aa9785] hover:text-white"
            }`}
          >
            Categories
          </button>
        </div>

        {/* TAB 1: ALL VIDEOS LIST */}
        {activeTab === "videos" && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-serif text-base font-bold text-[#fcf9f2]">
                Uploaded Video Archives
              </h3>
              <button
                onClick={() => setActiveTab("upload")}
                className="px-3 py-1.5 rounded-xl bg-[#8a6828] text-black font-serif text-xs font-bold hover:brightness-110 flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Video</span>
              </button>
            </div>

            {isLoadingVideos ? (
              <p className="text-xs text-stone-400 font-serif">Loading library...</p>
            ) : (
              <div className="rounded-2xl border border-[#483526] bg-[#1a130e] overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs font-serif">
                    <thead className="bg-[#241a13] text-[#cfbeab] border-b border-[#483526] font-mono text-[11px]">
                      <tr>
                        <th className="p-3">Thumbnail &amp; Title</th>
                        <th className="p-3">Category</th>
                        <th className="p-3">Type</th>
                        <th className="p-3">Duration</th>
                        <th className="p-3">Views</th>
                        <th className="p-3">Status</th>
                        <th className="p-3 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#35251a]">
                      {videosList.map((video) => (
                        <tr key={video.id} className="hover:bg-[#221811] transition-colors">
                          <td className="p-3 flex items-center gap-3">
                            <img
                              src={video.thumbnailUrl}
                              alt=""
                              className="w-14 h-9 object-cover rounded-lg border border-stone-800 shrink-0"
                            />
                            <div>
                              <p className="font-bold text-[#fcf9f2] line-clamp-1">{video.title}</p>
                              <p className="text-[10px] text-stone-400 font-mono truncate max-w-xs">{video.videoUrl}</p>
                            </div>
                          </td>
                          <td className="p-3 text-stone-300">
                            {video.category?.name || "General"}
                          </td>
                          <td className="p-3 font-mono text-[10px] uppercase text-amber-300">
                            {video.videoType}
                          </td>
                          <td className="p-3 font-mono text-stone-400">{video.duration}</td>
                          <td className="p-3 font-mono text-stone-300">{video.views}</td>
                          <td className="p-3">
                            <button
                              onClick={() => handleTogglePublish(video)}
                              className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold ${
                                video.isPublished
                                  ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/40"
                                  : "bg-stone-800 text-stone-400 border border-stone-700"
                              }`}
                            >
                              {video.isPublished ? "Published" : "Draft"}
                            </button>
                          </td>
                          <td className="p-3 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => setEditingVideo(video)}
                                className="p-1.5 rounded-lg bg-[#281e17] hover:bg-[#34271e] text-stone-300 hover:text-amber-300"
                                title="Edit video"
                              >
                                <Edit className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleDeleteVideo(video.id)}
                                className="p-1.5 rounded-lg bg-rose-950/30 hover:bg-rose-900/50 text-rose-300"
                                title="Delete video"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: UPLOAD / ADD VIDEO */}
        {activeTab === "upload" && (
          <div className="max-w-2xl mx-auto rounded-3xl bg-[#1b140e] border border-[#523d2b] p-6 space-y-5">
            <div>
              <h3 className="font-serif text-lg font-bold text-[#fcf9f2] flex items-center gap-2">
                <Upload className="w-5 h-5 text-[#d4af37]" />
                <span>Upload / Inscribe New Video Reel</span>
              </h3>
              <p className="text-xs text-[#a99887] font-serif">
                Videos are streamed via remote storage URLs (Cloudflare R2, Supabase, Firebase CDN)
              </p>
            </div>

            {/* Quick Demo Video Fillers */}
            <div className="p-3 rounded-2xl bg-[#241a13] border border-[#4a3627] space-y-2">
              <span className="text-[11px] font-bold text-[#f7dc78] font-serif">
                Fast Test Presets (Royalty-Free Open Source):
              </span>
              <div className="flex items-center gap-2 flex-wrap">
                {PRESET_DEMO_VIDEOS.map((demo, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setVideoForm({
                        ...videoForm,
                        title: demo.title,
                        videoUrl: demo.url,
                        thumbnailUrl: demo.thumb,
                        duration: demo.duration,
                        videoType: demo.type,
                      });
                    }}
                    className="px-2.5 py-1 rounded-lg bg-[#19110b] hover:bg-[#312317] border border-[#503b2c] text-[11px] font-serif text-[#e4d7c7] transition-colors"
                  >
                    + Use &quot;{demo.title}&quot;
                  </button>
                ))}
              </div>
            </div>

            {formSuccess && (
              <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-800 text-emerald-200 text-xs flex items-center gap-2">
                <CheckCircle className="w-4 h-4 shrink-0" />
                <span>{formSuccess}</span>
              </div>
            )}

            {formError && (
              <div className="p-3 rounded-xl bg-rose-950/40 border border-rose-800 text-rose-200 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleAddVideo} className="space-y-4">
              <div>
                <label className="block text-xs font-serif text-[#bcaaa0] mb-1">
                  Video Title *
                </label>
                <input
                  type="text"
                  required
                  value={videoForm.title}
                  onChange={(e) => setVideoForm({ ...videoForm, title: e.target.value })}
                  placeholder="e.g. Sintel: The Sacred Fire"
                  className="w-full px-3 py-2 rounded-xl bg-[#251c15] border border-[#4a3627] text-xs text-white focus:outline-none focus:border-[#d4af37]"
                />
              </div>

              <div>
                <label className="block text-xs font-serif text-[#bcaaa0] mb-1">
                  Description
                </label>
                <textarea
                  rows={3}
                  value={videoForm.description}
                  onChange={(e) => setVideoForm({ ...videoForm, description: e.target.value })}
                  placeholder="Cinematic synopsis or documentary notes..."
                  className="w-full px-3 py-2 rounded-xl bg-[#251c15] border border-[#4a3627] text-xs text-white focus:outline-none focus:border-[#d4af37] resize-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-serif text-[#bcaaa0] mb-1">
                    Category *
                  </label>
                  <select
                    value={videoForm.categoryId}
                    onChange={(e) => setVideoForm({ ...videoForm, categoryId: parseInt(e.target.value, 10) })}
                    className="w-full px-3 py-2 rounded-xl bg-[#251c15] border border-[#4a3627] text-xs text-white focus:outline-none focus:border-[#d4af37]"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.id} className="bg-[#251c15]">
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-serif text-[#bcaaa0] mb-1">
                    Video Type
                  </label>
                  <select
                    value={videoForm.videoType}
                    onChange={(e) => setVideoForm({ ...videoForm, videoType: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-[#251c15] border border-[#4a3627] text-xs text-white focus:outline-none focus:border-[#d4af37]"
                  >
                    <option value="movie" className="bg-[#251c15]">Movie</option>
                    <option value="short" className="bg-[#251c15]">Short Film</option>
                    <option value="documentary" className="bg-[#251c15]">Documentary</option>
                    <option value="series" className="bg-[#251c15]">Series Episode</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-serif text-[#bcaaa0] mb-1">
                  Remote Video Streaming URL (MP4 / HLS / CDN) *
                </label>
                <input
                  type="url"
                  required
                  value={videoForm.videoUrl}
                  onChange={(e) => setVideoForm({ ...videoForm, videoUrl: e.target.value })}
                  placeholder="https://storage.googleapis.com/... or https://r2.cloudflare.com/..."
                  className="w-full px-3 py-2 rounded-xl bg-[#251c15] border border-[#4a3627] text-xs font-mono text-white focus:outline-none focus:border-[#d4af37]"
                />
              </div>

              <div>
                <label className="block text-xs font-serif text-[#bcaaa0] mb-1">
                  Thumbnail Image URL
                </label>
                <input
                  type="url"
                  value={videoForm.thumbnailUrl}
                  onChange={(e) => setVideoForm({ ...videoForm, thumbnailUrl: e.target.value })}
                  placeholder="https://images.unsplash.com/photo-..."
                  className="w-full px-3 py-2 rounded-xl bg-[#251c15] border border-[#4a3627] text-xs font-mono text-white focus:outline-none focus:border-[#d4af37]"
                />
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-serif text-[#bcaaa0] mb-1">
                    Duration (e.g. 14:48)
                  </label>
                  <input
                    type="text"
                    value={videoForm.duration}
                    onChange={(e) => setVideoForm({ ...videoForm, duration: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-[#251c15] border border-[#4a3627] text-xs text-white focus:outline-none focus:border-[#d4af37]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-serif text-[#bcaaa0] mb-1">
                    Tags (comma separated)
                  </label>
                  <input
                    type="text"
                    value={videoForm.tagsInput}
                    onChange={(e) => setVideoForm({ ...videoForm, tagsInput: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-[#251c15] border border-[#4a3627] text-xs text-white focus:outline-none focus:border-[#d4af37]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-serif text-[#bcaaa0] mb-1">
                    Release Year
                  </label>
                  <input
                    type="number"
                    value={videoForm.releaseYear}
                    onChange={(e) => setVideoForm({ ...videoForm, releaseYear: parseInt(e.target.value, 10) })}
                    className="w-full px-3 py-2 rounded-xl bg-[#251c15] border border-[#4a3627] text-xs text-white focus:outline-none focus:border-[#d4af37]"
                  />
                </div>
              </div>

              <div className="flex items-center gap-6 pt-2">
                <label className="flex items-center gap-2 text-xs font-serif cursor-pointer">
                  <input
                    type="checkbox"
                    checked={videoForm.isFeatured}
                    onChange={(e) => setVideoForm({ ...videoForm, isFeatured: e.target.checked })}
                    className="accent-[#d4af37]"
                  />
                  <span>Feature on Hero Banner</span>
                </label>

                <label className="flex items-center gap-2 text-xs font-serif cursor-pointer">
                  <input
                    type="checkbox"
                    checked={videoForm.isPublished}
                    onChange={(e) => setVideoForm({ ...videoForm, isPublished: e.target.checked })}
                    className="accent-[#d4af37]"
                  />
                  <span>Publish Immediately</span>
                </label>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#9b7536] via-[#cf9e42] to-[#9b7536] text-[#160f06] font-serif font-bold text-xs shadow-lg hover:brightness-110 disabled:opacity-50 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>{isSubmitting ? "Archiving Reel..." : "Inscribe & Publish Video"}</span>
              </button>
            </form>
          </div>
        )}

        {/* TAB 3: STORAGE ARCHITECTURE CONFIGURATION */}
        {activeTab === "storage" && (
          <div className="max-w-3xl mx-auto rounded-3xl bg-[#1b140e] border border-[#523d2b] p-6 space-y-4">
            <div className="flex items-center gap-2.5">
              <HardDrive className="w-6 h-6 text-[#d4af37]" />
              <div>
                <h3 className="font-serif text-lg font-bold text-[#fcf9f2]">
                  Remote Video Storage &amp; Streaming Architecture
                </h3>
                <p className="text-xs text-[#a99887] font-serif">
                  Strictly non-embedded video CDN integration guide
                </p>
              </div>
            </div>

            <p className="text-xs text-[#cfbeab] font-serif leading-relaxed">
              Magic Book is engineered with zero video assets in the frontend bundle. All video files are served through high-performance streaming URL endpoints. You can plug in any of the following storage providers:
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="p-4 rounded-2xl bg-[#241a13] border border-[#4d3827] space-y-2">
                <div className="flex items-center gap-2 font-serif text-sm font-bold text-[#f7dc78]">
                  <CloudflareIcon />
                  <span>Cloudflare R2 (Recommended)</span>
                </div>
                <p className="text-xs text-stone-300">
                  Zero egress fees. S3-compatible API. Simply point your video URLs to your custom R2 domain (e.g. `https://media.magicbook.com/videos/shivaay-saga.mp4`).
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-[#241a13] border border-[#4d3827] space-y-2">
                <div className="flex items-center gap-2 font-serif text-sm font-bold text-[#f7dc78]">
                  <FirebaseIcon />
                  <span>Firebase / Google Cloud Storage</span>
                </div>
                <p className="text-xs text-stone-300">
                  Seamless CDN delivery. Supports HLS chunking or raw MP4 byte-range requests for smooth seeking.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-[#241a13] border border-[#4d3827] space-y-2">
                <div className="flex items-center gap-2 font-serif text-sm font-bold text-[#f7dc78]">
                  <SupabaseIcon />
                  <span>Supabase Storage</span>
                </div>
                <p className="text-xs text-stone-300">
                  Built-in PostgreSQL storage buckets with public URL CDN distribution.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-[#241a13] border border-[#4d3827] space-y-2">
                <div className="flex items-center gap-2 font-serif text-sm font-bold text-[#f7dc78]">
                  <AwsIcon />
                  <span>Amazon S3 + CloudFront</span>
                </div>
                <p className="text-xs text-stone-300">
                  Industry standard edge streaming CDN with multi-bitrate HLS support.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: CATEGORIES MANAGER */}
        {activeTab === "categories" && (
          <div className="max-w-2xl mx-auto space-y-5">
            <div className="rounded-3xl bg-[#1b140e] border border-[#523d2b] p-6 space-y-4">
              <h3 className="font-serif text-base font-bold text-[#fcf9f2] flex items-center gap-2">
                <Plus className="w-4 h-4 text-[#d4af37]" />
                <span>Create New Video Category</span>
              </h3>

              <form onSubmit={handleAddCategory} className="space-y-3">
                <input
                  type="text"
                  required
                  value={newCatName}
                  onChange={(e) => setNewCatName(e.target.value)}
                  placeholder="Category Name (e.g. Vedic Epics)"
                  className="w-full px-3 py-2 rounded-xl bg-[#251c15] border border-[#4a3627] text-xs text-white focus:outline-none focus:border-[#d4af37]"
                />
                <input
                  type="text"
                  value={newCatDesc}
                  onChange={(e) => setNewCatDesc(e.target.value)}
                  placeholder="Short Description"
                  className="w-full px-3 py-2 rounded-xl bg-[#251c15] border border-[#4a3627] text-xs text-white focus:outline-none focus:border-[#d4af37]"
                />
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-[#8a6828] text-black font-serif text-xs font-bold hover:brightness-110 cursor-pointer"
                >
                  Create Category
                </button>
              </form>
            </div>

            <div className="rounded-2xl border border-[#483526] bg-[#1a130e] p-4 space-y-2">
              <h4 className="font-serif text-sm font-bold text-[#f7dc78]">
                Existing Categories
              </h4>
              <div className="divide-y divide-[#342419]">
                {categories.map((c) => (
                  <div key={c.id} className="py-2 flex items-center justify-between text-xs">
                    <div>
                      <p className="font-bold text-[#fcf9f2]">{c.name}</p>
                      <p className="text-[10px] text-stone-400">{c.description || "No description"}</p>
                    </div>
                    <span className="font-mono text-stone-400 text-[10px]">{c.videoCount || 0} reels</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* EDIT VIDEO MODAL */}
        {editingVideo && (
          <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
            <div className="w-full max-w-xl rounded-3xl bg-[#1d1611] border border-[#523e2e] p-6 space-y-4 max-h-[90vh] overflow-y-auto">
              <div className="flex items-center justify-between border-b border-[#3d2e23] pb-3">
                <h3 className="font-serif text-base font-bold text-[#fcf9f2]">
                  Edit Video: {editingVideo.title}
                </h3>
                <button
                  onClick={() => setEditingVideo(null)}
                  className="text-stone-400 hover:text-white"
                >
                  ✕
                </button>
              </div>

              <form onSubmit={handleUpdateVideo} className="space-y-3">
                <div>
                  <label className="block text-xs font-serif text-stone-300 mb-1">Title</label>
                  <input
                    type="text"
                    value={editingVideo.title}
                    onChange={(e) => setEditingVideo({ ...editingVideo, title: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-[#251c15] border border-[#4a3627] text-xs text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-serif text-stone-300 mb-1">Description</label>
                  <textarea
                    rows={3}
                    value={editingVideo.description}
                    onChange={(e) => setEditingVideo({ ...editingVideo, description: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-[#251c15] border border-[#4a3627] text-xs text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-serif text-stone-300 mb-1">Video Stream URL</label>
                  <input
                    type="url"
                    value={editingVideo.videoUrl}
                    onChange={(e) => setEditingVideo({ ...editingVideo, videoUrl: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-[#251c15] border border-[#4a3627] text-xs font-mono text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-serif text-stone-300 mb-1">Thumbnail URL</label>
                  <input
                    type="url"
                    value={editingVideo.thumbnailUrl}
                    onChange={(e) => setEditingVideo({ ...editingVideo, thumbnailUrl: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-[#251c15] border border-[#4a3627] text-xs font-mono text-white"
                  />
                </div>

                <div className="flex items-center gap-6 pt-2">
                  <label className="flex items-center gap-2 text-xs font-serif cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editingVideo.isFeatured}
                      onChange={(e) => setEditingVideo({ ...editingVideo, isFeatured: e.target.checked })}
                      className="accent-[#d4af37]"
                    />
                    <span>Featured</span>
                  </label>

                  <label className="flex items-center gap-2 text-xs font-serif cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editingVideo.isPublished}
                      onChange={(e) => setEditingVideo({ ...editingVideo, isPublished: e.target.checked })}
                      className="accent-[#d4af37]"
                    />
                    <span>Published</span>
                  </label>
                </div>

                <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#3d2e23]">
                  <button
                    type="button"
                    onClick={() => setEditingVideo(null)}
                    className="px-3 py-1.5 rounded-xl bg-stone-800 text-stone-300 text-xs font-serif"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded-xl bg-[#8a6828] text-black font-serif text-xs font-bold hover:brightness-110"
                  >
                    Save Changes
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

// Simple brand icons for storage providers
function CloudflareIcon() {
  return <div className="w-4 h-4 rounded bg-orange-500/20 text-orange-400 font-mono text-[9px] flex items-center justify-center font-bold">R2</div>;
}

function FirebaseIcon() {
  return <div className="w-4 h-4 rounded bg-yellow-500/20 text-yellow-400 font-mono text-[9px] flex items-center justify-center font-bold">FB</div>;
}

function SupabaseIcon() {
  return <div className="w-4 h-4 rounded bg-emerald-500/20 text-emerald-400 font-mono text-[9px] flex items-center justify-center font-bold">SB</div>;
}

function AwsIcon() {
  return <div className="w-4 h-4 rounded bg-sky-500/20 text-sky-400 font-mono text-[9px] flex items-center justify-center font-bold">S3</div>;
}
