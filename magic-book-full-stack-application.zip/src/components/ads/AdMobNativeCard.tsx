"use client";

import React from "react";
import { DEFAULT_ADMOB_CONFIG } from "@/lib/admob";
import { ExternalLink, ShieldCheck } from "lucide-react";

export function AdMobNativeCard({ className = "" }: { className?: string }) {
  return (
    <div
      className={`rounded-2xl border border-dashed border-amber-700/40 bg-[#1f1914] p-4 relative overflow-hidden transition-all hover:border-amber-600/60 ${className}`}
      data-admob-unit={DEFAULT_ADMOB_CONFIG.nativeAdUnitId}
      data-admob-type="native-advanced"
    >
      <div className="flex items-center justify-between mb-2">
        <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/40">
          Sponsored
        </span>
        <div className="flex items-center gap-1 text-[10px] text-amber-200/50">
          <ShieldCheck className="w-3 h-3 text-emerald-400" />
          <span>Verified Sponsor</span>
        </div>
      </div>

      <div className="space-y-2">
        <h4 className="font-serif text-sm font-semibold text-amber-100">
          Curated Scribe & Fountain Pen Guild
        </h4>
        <p className="text-xs text-amber-200/70 line-clamp-2 leading-relaxed">
          Discover handcrafted brass pens, archival sepia ink, and watermarked cotton paper journals made for lifelong reflections.
        </p>
      </div>

      <div className="mt-3 pt-3 border-t border-amber-900/30 flex items-center justify-between">
        <span className="text-[10px] text-stone-400 font-mono">
          AdMob Native: {DEFAULT_ADMOB_CONFIG.nativeAdUnitId.slice(0, 16)}...
        </span>
        <button
          onClick={() => {
            alert("Google AdMob architecture active. Configured for production ad unit IDs.");
          }}
          className="inline-flex items-center gap-1.5 px-3 py-1 rounded bg-amber-600/20 hover:bg-amber-600/30 border border-amber-500/40 text-amber-200 text-xs font-medium transition-colors"
        >
          <span>Explore</span>
          <ExternalLink className="w-3 h-3" />
        </button>
      </div>
    </div>
  );
}
