"use client";

import React, { useState } from "react";
import { DEFAULT_ADMOB_CONFIG } from "@/lib/admob";
import { Info, Sparkles, X } from "lucide-react";

interface AdMobBannerProps {
  placement?: "bottom-docked" | "inline" | "header";
  className?: string;
}

export function AdMobBanner({ placement = "inline", className = "" }: AdMobBannerProps) {
  const [showInfo, setShowInfo] = useState(false);

  return (
    <div
      className={`relative w-full max-w-xl mx-auto rounded-xl border border-amber-900/30 bg-[#211a14]/90 p-3 shadow-md backdrop-blur-sm transition-all ${className}`}
      data-admob-unit={DEFAULT_ADMOB_CONFIG.bannerAdUnitId}
      data-admob-type="adaptive-banner"
    >
      <div className="flex items-center justify-between pb-1.5 border-b border-amber-900/20 text-[10px] text-amber-200/60 uppercase tracking-wider font-mono">
        <div className="flex items-center gap-1.5">
          <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
            Ad
          </span>
          <span>Google AdMob Ready</span>
        </div>
        <button
          onClick={() => setShowInfo(!showInfo)}
          className="hover:text-amber-300 transition-colors flex items-center gap-1"
          title="AdMob Integration Information"
        >
          <Info className="w-3 h-3" />
          <span>Config</span>
        </button>
      </div>

      <div className="py-2.5 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-amber-600/30 to-amber-900/40 border border-amber-500/30 flex items-center justify-center shrink-0">
            <Sparkles className="w-5 h-5 text-amber-400" />
          </div>
          <div className="min-w-0">
            <p className="text-xs font-semibold text-amber-100 truncate">
              Magic Book Companion App
            </p>
            <p className="text-[11px] text-amber-300/70 truncate">
              Seamless cloud sync & offline reading suite
            </p>
          </div>
        </div>

        <a
          href="#admob-info"
          onClick={(e) => {
            e.preventDefault();
            setShowInfo(true);
          }}
          className="px-3 py-1.5 rounded-lg bg-amber-600/30 hover:bg-amber-600/50 text-amber-200 border border-amber-500/40 text-xs font-medium shrink-0 transition-colors"
        >
          Learn More
        </a>
      </div>

      {showInfo && (
        <div className="mt-2 pt-2 border-t border-amber-900/30 text-[11px] text-amber-200/80 bg-black/40 rounded p-2 relative">
          <button
            onClick={() => setShowInfo(false)}
            className="absolute top-1.5 right-1.5 text-amber-400 hover:text-white"
          >
            <X className="w-3.5 h-3.5" />
          </button>
          <p className="font-semibold text-amber-300 mb-1">AdMob Compliance & Architecture:</p>
          <p className="font-mono text-[10px] text-amber-400/90 break-all mb-1">
            Unit ID: {DEFAULT_ADMOB_CONFIG.bannerAdUnitId}
          </p>
          <p className="text-stone-300 text-[10px] leading-relaxed">
            Policy Compliant: Clear ad label, safe interactive spacing, non-intrusive container. Ready for Play Store injection.
          </p>
        </div>
      )}
    </div>
  );
}
