"use client";

import React from "react";
import { AppMode } from "@/types";
import {
  BookOpen,
  FileText,
  Search,
  Settings,
  Film,
  Clock,
  FolderOpen,
  Bookmark,
  Home,
  Sparkles,
  ArrowLeft,
} from "lucide-react";
import { sounds } from "@/lib/sound";

interface BottomNavProps {
  mode: AppMode;
  currentTab: string;
  onTabChange: (tab: string) => void;
  onReturnToNotebook?: () => void;
}

export function BottomNav({
  mode,
  currentTab,
  onTabChange,
  onReturnToNotebook,
}: BottomNavProps) {
  if (mode === "admin") return null;

  if (mode === "notebook") {
    const tabs = [
      { id: "desk", label: "Home", icon: Home },
      { id: "notes", label: "Notes", icon: FileText },
      { id: "search", label: "Search", icon: Search },
      { id: "settings", label: "Settings", icon: Settings },
    ];

    return (
      <nav
        aria-label="Notebook Navigation"
        className="fixed bottom-0 inset-x-0 z-40 bg-[#1e1712]/95 backdrop-blur-md border-t border-[#453325] text-[#ede4d8] shadow-2xl safe-bottom"
      >
        <div className="max-w-md mx-auto px-4 py-2 flex items-center justify-around">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = currentTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  sounds.playPageTurn();
                  onTabChange(tab.id);
                }}
                className={`flex flex-col items-center justify-center py-1 px-3 rounded-2xl transition-all cursor-pointer ${
                  isActive
                    ? "text-[#f7dc78] font-bold"
                    : "text-[#aa9684] hover:text-[#f7dc78]"
                }`}
              >
                <div
                  className={`p-1 rounded-xl transition-all ${
                    isActive ? "bg-[#d4af37]/20 border border-[#d4af37]/40 shadow-sm" : ""
                  }`}
                >
                  <Icon className="w-5 h-5 stroke-[2.2]" />
                </div>
                <span className="text-[10px] font-serif tracking-wider mt-0.5">
                  {tab.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>
    );
  }

  // SHIVAAY MODE NAVIGATION
  const shivaayTabs = [
    { id: "home", label: "Home", icon: Home },
    { id: "movies", label: "Movies", icon: Film },
    { id: "latest", label: "Latest", icon: Clock },
    { id: "categories", label: "Genres", icon: FolderOpen },
    { id: "saved", label: "Saved", icon: Bookmark },
  ];

  return (
    <nav
      aria-label="Shivaay Cinema Navigation"
      className="fixed bottom-0 inset-x-0 z-40 bg-[#120d09]/98 backdrop-blur-md border-t border-[#483321] text-[#f7efe4] shadow-2xl safe-bottom"
    >
      <div className="max-w-lg mx-auto px-3 py-1.5 flex items-center justify-around">
        {shivaayTabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = currentTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition-all cursor-pointer ${
                isActive
                  ? "text-[#fcdb77] font-bold"
                  : "text-[#a4917f] hover:text-[#fcdb77]"
              }`}
            >
              <div
                className={`p-1 rounded-lg transition-all ${
                  isActive ? "bg-[#d4af37]/25 border border-[#d4af37]/50 shadow-md" : ""
                }`}
              >
                <Icon className="w-4 h-4 sm:w-5 sm:h-5 stroke-[2.2]" />
              </div>
              <span className="text-[10px] font-serif tracking-wide mt-0.5">
                {tab.label}
              </span>
            </button>
          );
        })}

        {/* Quick Return to Notebook Button */}
        {onReturnToNotebook && (
          <button
            onClick={onReturnToNotebook}
            className="flex flex-col items-center justify-center py-1 px-2 text-[#d4af37] hover:text-white transition-all cursor-pointer"
            title="Return to Journal"
          >
            <div className="p-1 rounded-lg bg-[#2a1d13] border border-[#78592f]">
              <ArrowLeft className="w-4 h-4 text-amber-400" />
            </div>
            <span className="text-[10px] font-serif tracking-wide mt-0.5">
              Journal
            </span>
          </button>
        )}
      </div>
    </nav>
  );
}
