"use client";

import React from "react";
import { VideoItem } from "@/types";
import { Play, Bookmark, Star, Clock, Sparkles } from "lucide-react";

interface ShivaayHeroProps {
  video: VideoItem;
  onPlay: (video: VideoItem) => void;
  isSaved: boolean;
  onToggleSave: (videoId: number) => void;
}

export function ShivaayHero({
  video,
  onPlay,
  isSaved,
  onToggleSave,
}: ShivaayHeroProps) {
  const tags: string[] = (() => {
    try {
      return JSON.parse(video.tags);
    } catch {
      return [];
    }
  })();

  return (
    <section className="relative rounded-3xl overflow-hidden border border-[#5d4633] shadow-2xl bg-[#17110c] text-[#f7efe4] min-h-[380px] sm:min-h-[440px] flex flex-col justify-end">
      {/* Background Thumbnail Image with Cinematic Vignette & Gradient */}
      <div
        className="absolute inset-0 bg-cover bg-center transition-transform duration-700 hover:scale-105"
        style={{ backgroundImage: `url(${video.thumbnailUrl})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-[#120e0a] via-[#120e0a]/80 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#120e0a] via-[#120e0a]/60 to-transparent" />
        {/* Subtle warm grain overlay */}
        <div className="absolute inset-0 bg-amber-950/20 mix-blend-color-burn" />
      </div>

      {/* Hero Content */}
      <div className="relative p-6 sm:p-10 z-10 max-w-2xl space-y-3.5">
        {/* Badges */}
        <div className="flex items-center gap-2 flex-wrap">
          <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs font-serif font-bold uppercase tracking-wider flex items-center gap-1">
            <Sparkles className="w-3 h-3" />
            <span>Featured Reel</span>
          </span>

          {video.category && (
            <span className="px-2.5 py-0.5 rounded-full bg-stone-900/80 border border-stone-700 text-stone-200 text-xs font-serif">
              {video.category.name}
            </span>
          )}

          <div className="flex items-center gap-1 text-xs text-amber-300">
            <Star className="w-3.5 h-3.5 fill-amber-400" />
            <span className="font-bold">{video.rating}</span>
          </div>

          <div className="flex items-center gap-1 text-xs text-stone-300">
            <Clock className="w-3.5 h-3.5" />
            <span>{video.duration}</span>
          </div>
        </div>

        {/* Title */}
        <h2 className="font-serif text-2xl sm:text-4xl font-extrabold tracking-tight text-[#fdf8f0] leading-tight drop-shadow-md">
          {video.title}
        </h2>

        {/* Description Excerpt */}
        <p className="text-xs sm:text-sm text-[#ded1c2] leading-relaxed line-clamp-3 font-serif drop-shadow">
          {video.description}
        </p>

        {/* Tags */}
        {tags.length > 0 && (
          <div className="flex items-center gap-1.5 flex-wrap pt-1">
            {tags.slice(0, 4).map((t, idx) => (
              <span
                key={idx}
                className="text-[11px] font-sans px-2 py-0.5 rounded bg-black/40 border border-amber-900/30 text-amber-200/80"
              >
                #{t}
              </span>
            ))}
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex items-center gap-3 pt-2">
          <button
            onClick={() => onPlay(video)}
            className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#c59c44] via-[#f0cf7e] to-[#b38833] hover:brightness-110 active:scale-95 text-[#191107] font-serif font-bold text-sm shadow-xl flex items-center gap-2 transition-all cursor-pointer"
          >
            <Play className="w-4 h-4 fill-current stroke-none" />
            <span>Watch Reel</span>
          </button>

          <button
            onClick={() => onToggleSave(video.id)}
            className={`px-4 py-2.5 rounded-xl border flex items-center gap-2 text-xs sm:text-sm font-serif font-medium transition-all ${
              isSaved
                ? "bg-amber-500/20 border-amber-500/50 text-amber-200"
                : "bg-black/40 hover:bg-black/60 border-stone-700 text-stone-200"
            }`}
          >
            <Bookmark className={`w-4 h-4 ${isSaved ? "fill-amber-400 text-amber-400" : ""}`} />
            <span>{isSaved ? "Saved" : "Save to Reel"}</span>
          </button>
        </div>
      </div>
    </section>
  );
}
