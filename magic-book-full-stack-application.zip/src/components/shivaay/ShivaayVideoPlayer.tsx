"use client";

import React, { useState, useRef, useEffect } from "react";
import { VideoItem } from "@/types";
import { ShivaayVideoCard } from "./ShivaayVideoCard";
import { AdMobBanner } from "../ads/AdMobBanner";
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize,
  Minimize,
  RotateCcw,
  RotateCw,
  Bookmark,
  Share2,
  ArrowLeft,
  Star,
  Clock,
  Eye,
  Sparkles,
  Layers,
} from "lucide-react";

interface ShivaayVideoPlayerProps {
  video: VideoItem;
  relatedVideos: VideoItem[];
  onSelectVideo: (video: VideoItem) => void;
  onClose: () => void;
  isSaved: boolean;
  onToggleSave: (videoId: number) => void;
}

export function ShivaayVideoPlayer({
  video,
  relatedVideos,
  onSelectVideo,
  onClose,
  isSaved,
  onToggleSave,
}: ShivaayVideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.85);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [showControls, setShowControls] = useState(true);
  const [hasCopiedShare, setHasCopiedShare] = useState(false);
  const controlsTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Play video on mount or when video URL changes
  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.currentTime = 0;
      videoRef.current
        .play()
        .then(() => setIsPlaying(true))
        .catch(() => {
          // Autoplay may be restricted without user interaction
          setIsPlaying(false);
        });
    }
  }, [video.videoUrl]);

  // Handle controls hide timer
  const handleMouseMove = () => {
    setShowControls(true);
    if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current);
    if (isPlaying) {
      controlsTimeoutRef.current = setTimeout(() => {
        setShowControls(false);
      }, 3500);
    }
  };

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
      setShowControls(true);
    } else {
      videoRef.current.play();
      setIsPlaying(true);
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
      if (!duration && videoRef.current.duration) {
        setDuration(videoRef.current.duration);
      }
    }
  };

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const target = parseFloat(e.target.value);
    setCurrentTime(target);
    if (videoRef.current) {
      videoRef.current.currentTime = target;
    }
  };

  const handleSkip = (seconds: number) => {
    if (videoRef.current) {
      videoRef.current.currentTime = Math.min(
        Math.max(videoRef.current.currentTime + seconds, 0),
        duration
      );
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    if (videoRef.current) {
      videoRef.current.volume = val;
      videoRef.current.muted = val === 0;
    }
    setIsMuted(val === 0);
  };

  const toggleMute = () => {
    if (!videoRef.current) return;
    if (isMuted) {
      videoRef.current.muted = false;
      videoRef.current.volume = volume || 0.5;
      setIsMuted(false);
    } else {
      videoRef.current.muted = true;
      setIsMuted(true);
    }
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().catch((err) => console.error(err));
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch((err) => console.error(err));
      setIsFullscreen(false);
    }
  };

  const cycleSpeed = () => {
    const speeds = [1, 1.25, 1.5, 2, 0.75];
    const nextIdx = (speeds.indexOf(playbackSpeed) + 1) % speeds.length;
    const nextSpeed = speeds[nextIdx];
    setPlaybackSpeed(nextSpeed);
    if (videoRef.current) {
      videoRef.current.playbackRate = nextSpeed;
    }
  };

  const formatTime = (secs: number) => {
    if (isNaN(secs) || secs < 0) return "0:00";
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? "0" : ""}${s}`;
  };

  const handleShare = () => {
    if (typeof navigator !== "undefined" && navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      setHasCopiedShare(true);
      setTimeout(() => setHasCopiedShare(false), 2000);
    }
  };

  const tags: string[] = (() => {
    try {
      return JSON.parse(video.tags);
    } catch {
      return [];
    }
  })();

  return (
    <div className="space-y-6 pb-24 max-w-5xl mx-auto px-2 sm:px-4 pt-2 text-[#f7efe4] animate-in fade-in duration-300">
      {/* Back button */}
      <div className="flex items-center justify-between">
        <button
          onClick={onClose}
          className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#231b15] hover:bg-[#34271e] border border-[#483627] text-xs font-serif text-[#e7d8c5] transition-colors"
        >
          <ArrowLeft className="w-4 h-4 text-[#d4af37]" />
          <span>Back to Shivaay Library</span>
        </button>

        <span className="text-[11px] font-mono text-stone-400">
          Cinema Reel #{video.id}
        </span>
      </div>

      {/* Video Player Display */}
      <div
        ref={containerRef}
        onMouseMove={handleMouseMove}
        className="relative w-full aspect-video rounded-3xl overflow-hidden bg-black shadow-2xl border border-[#523d2b] group select-none"
      >
        <video
          ref={videoRef}
          src={video.videoUrl}
          poster={video.thumbnailUrl}
          onTimeUpdate={handleTimeUpdate}
          onLoadedMetadata={handleLoadedMetadata}
          onClick={togglePlay}
          playsInline
          className="w-full h-full object-contain cursor-pointer"
        />

        {/* Center Big Play Button when paused */}
        {!isPlaying && (
          <div
            onClick={togglePlay}
            className="absolute inset-0 flex items-center justify-center bg-black/40 cursor-pointer backdrop-blur-[2px]"
          >
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-gradient-to-br from-[#d4af37] to-[#8c6d1d] flex items-center justify-center shadow-2xl transform hover:scale-110 active:scale-95 transition-all text-black">
              <Play className="w-8 h-8 fill-current ml-1" />
            </div>
          </div>
        )}

        {/* Custom Controls Bar */}
        <div
          className={`absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/95 via-black/80 to-transparent p-3 sm:p-5 transition-opacity duration-300 ${
            showControls ? "opacity-100" : "opacity-0 pointer-events-none"
          }`}
        >
          {/* Progress / Seek bar */}
          <div className="space-y-1 mb-2">
            <input
              type="range"
              min={0}
              max={duration || 100}
              value={currentTime}
              onChange={handleSeek}
              className="w-full h-1.5 bg-stone-700 rounded-lg appearance-none cursor-pointer accent-[#d4af37]"
            />
            <div className="flex items-center justify-between text-[11px] font-mono text-stone-300">
              <span>{formatTime(currentTime)}</span>
              <span>{formatTime(duration)}</span>
            </div>
          </div>

          {/* Control Buttons Row */}
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 sm:gap-3">
              {/* Play / Pause */}
              <button
                onClick={togglePlay}
                className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-[#f5ebd9] transition-colors"
                title={isPlaying ? "Pause" : "Play"}
              >
                {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
              </button>

              {/* Skip -10s */}
              <button
                onClick={() => handleSkip(-10)}
                className="p-1.5 text-stone-300 hover:text-white"
                title="Rewind 10 seconds"
              >
                <RotateCcw className="w-4 h-4" />
              </button>

              {/* Skip +10s */}
              <button
                onClick={() => handleSkip(10)}
                className="p-1.5 text-stone-300 hover:text-white"
                title="Forward 10 seconds"
              >
                <RotateCw className="w-4 h-4" />
              </button>

              {/* Volume & Mute */}
              <div className="flex items-center gap-1.5">
                <button
                  onClick={toggleMute}
                  className="p-1.5 text-stone-300 hover:text-white"
                  title={isMuted ? "Unmute" : "Mute"}
                >
                  {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </button>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={isMuted ? 0 : volume}
                  onChange={handleVolumeChange}
                  className="w-14 sm:w-20 h-1 bg-stone-700 rounded appearance-none cursor-pointer accent-[#d4af37]"
                />
              </div>
            </div>

            <div className="flex items-center gap-2">
              {/* Speed Cycle */}
              <button
                onClick={cycleSpeed}
                className="px-2 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-[11px] font-mono text-amber-300"
                title="Playback Speed"
              >
                {playbackSpeed}x
              </button>

              {/* Fullscreen */}
              <button
                onClick={toggleFullscreen}
                className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-[#f5ebd9] transition-colors"
                title={isFullscreen ? "Exit Fullscreen" : "Fullscreen"}
              >
                {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Video Information & Meta Details */}
      <section className="p-5 sm:p-7 rounded-3xl bg-[#1b140f] border border-[#483626] shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 flex-wrap text-xs">
              <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 font-serif font-bold uppercase tracking-wider">
                {video.videoType}
              </span>

              {video.category && (
                <span className="text-stone-300 font-serif">
                  {video.category.name}
                </span>
              )}

              <span className="text-stone-500">•</span>
              <span className="text-stone-400 font-mono">{video.releaseYear}</span>
              <span className="text-stone-500">•</span>

              <div className="flex items-center gap-1 text-amber-400 font-bold">
                <Star className="w-3.5 h-3.5 fill-amber-400" />
                <span>{video.rating}</span>
              </div>

              <span className="text-stone-500">•</span>
              <div className="flex items-center gap-1 text-stone-400 font-mono">
                <Eye className="w-3.5 h-3.5" />
                <span>{video.views} plays</span>
              </div>
            </div>

            <h1 className="font-serif text-2xl sm:text-3xl font-bold tracking-tight text-[#fdf8f0]">
              {video.title}
            </h1>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => onToggleSave(video.id)}
              className={`px-4 py-2 rounded-xl border flex items-center gap-2 text-xs font-serif font-semibold transition-all ${
                isSaved
                  ? "bg-amber-500/20 border-amber-500/40 text-amber-300"
                  : "bg-[#251c15] hover:bg-[#34271e] border-[#4d3827] text-[#dcd1c2]"
              }`}
            >
              <Bookmark className={`w-4 h-4 ${isSaved ? "fill-amber-400 text-amber-400" : ""}`} />
              <span>{isSaved ? "Saved to Reel" : "Add to Reel"}</span>
            </button>

            <button
              onClick={handleShare}
              className="p-2 rounded-xl bg-[#251c15] hover:bg-[#34271e] border border-[#4d3827] text-stone-300 hover:text-white transition-colors"
              title="Share reel"
            >
              <Share2 className="w-4 h-4" />
            </button>
            {hasCopiedShare && (
              <span className="text-[11px] text-amber-300 font-serif">Link copied!</span>
            )}
          </div>
        </div>

        {/* Video Description */}
        <p className="text-xs sm:text-sm text-[#ded1c2] font-serif leading-relaxed pt-2 border-t border-[#34251a]">
          {video.description}
        </p>

        {/* Tags */}
        {tags.length > 0 && (
          <div className="flex items-center gap-1.5 flex-wrap pt-2">
            <span className="text-[11px] text-stone-500 font-mono">Tags:</span>
            {tags.map((t, idx) => (
              <span
                key={idx}
                className="text-[11px] font-sans px-2.5 py-0.5 rounded-full bg-black/40 border border-[#3e2e21] text-amber-200/80"
              >
                #{t}
              </span>
            ))}
          </div>
        )}
      </section>

      {/* Related Videos Shelf */}
      {relatedVideos.length > 0 && (
        <section className="space-y-3 pt-2">
          <div className="flex items-center gap-2 text-sm font-serif font-bold text-[#f7dc78]">
            <Layers className="w-4 h-4 text-[#d4af37]" />
            <span>Related Manuscripts &amp; Reels</span>
            <span className="text-stone-500 font-mono text-xs">({relatedVideos.length})</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {relatedVideos.map((item) => (
              <ShivaayVideoCard
                key={item.id}
                video={item}
                onPlay={(v) => {
                  window.scrollTo({ top: 0, behavior: "smooth" });
                  onSelectVideo(v);
                }}
                isSaved={false}
                onToggleSave={(id, e) => {
                  e.stopPropagation();
                  onToggleSave(id);
                }}
              />
            ))}
          </div>
        </section>
      )}

      {/* Compliant Ad Slot */}
      <section className="pt-4">
        <AdMobBanner placement="inline" />
      </section>
    </div>
  );
}
