"use client";

import React from "react";
import { Search, Film, Bookmark, BookOpen, X, Sparkles, Flame, Eye } from "lucide-react";
import { CategoryItem } from "@/types";

interface ShivaayHeaderProps {
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onReturnToNotebook: () => void;
  activeNav: string;
  onNavChange: (nav: string) => void;
  categories: CategoryItem[];
  selectedCategory: string | null;
  onSelectCategory: (slug: string | null) => void;
  savedCount: number;
}

export function ShivaayHeader({
  searchQuery,
  onSearchChange,
  onReturnToNotebook,
  activeNav,
  onNavChange,
  categories,
  selectedCategory,
  onSelectCategory,
  savedCount,
}: ShivaayHeaderProps) {
  return (
    <header className="sticky top-0 z-30 bg-[#120e0b]/95 backdrop-blur-md border-b border-[#3e2e21] shadow-2xl text-[#f5ebd9]">
      <div className="max-w-6xl mx-auto px-4 py-3">
        {/* Brand & Mode Switcher */}
        <div className="flex items-center justify-between gap-3 mb-2.5">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#f3cf7a] via-[#c49339] to-[#614515] p-0.5 shadow-lg flex items-center justify-center">
              <div className="w-full h-full bg-[#17110c] rounded-[10px] flex items-center justify-center">
                <Flame className="w-5 h-5 text-[#fadc82] animate-pulse" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-serif text-lg font-black tracking-tight text-[#fdf8f0]">
                  SHIVAAY
                </h1>
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 bg-[#d4af37]/20 text-[#f5d88f] rounded-full border border-[#d4af37]/40 flex items-center gap-1 font-bold">
                  <Sparkles className="w-2.5 h-2.5" />
                  <span>Magic Reel</span>
                </span>
              </div>
              <p className="text-[10px] text-[#aa9784] hidden sm:block">
                The Enchanted Cinema Library • Unlocked Sanctuary
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Watchlist Counter */}
            <button
              onClick={() => onNavChange("saved")}
              className={`px-3 py-1.5 rounded-xl border flex items-center gap-1.5 text-xs font-serif transition-all ${
                activeNav === "saved"
                  ? "bg-[#d4af37]/20 border-[#d4af37]/50 text-[#f7dc78]"
                  : "bg-[#201812] border-[#433123] text-[#d1c2b0] hover:bg-[#2b2018]"
              }`}
            >
              <Bookmark className={`w-3.5 h-3.5 ${savedCount > 0 ? "fill-amber-400 text-amber-400" : ""}`} />
              <span className="hidden sm:inline">Saved</span>
              <span className="px-1.5 py-0.2 bg-amber-500/20 rounded-full font-mono text-[10px] text-amber-300">
                {savedCount}
              </span>
            </button>

            {/* Return to Notebook Button */}
            <button
              onClick={onReturnToNotebook}
              className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-[#3e2c1e] to-[#281b12] hover:bg-[#4d3725] border border-[#7a5933] text-[#f2e6d6] font-serif font-semibold text-xs shadow-md flex items-center gap-1.5 transition-all"
              title="Return to Notebook Home"
            >
              <BookOpen className="w-4 h-4 text-[#d4af37]" />
              <span className="hidden sm:inline">Return to Journal</span>
              <span className="sm:hidden">Journal</span>
            </button>
          </div>
        </div>

        {/* Video Search Bar */}
        <div className="relative mb-2">
          <div className="relative flex items-center rounded-xl bg-[#1e1711] border border-[#4a3626] focus-within:border-[#c59c44] focus-within:ring-2 focus-within:ring-[#c59c44]/30">
            <div className="pl-3.5 pr-2 flex items-center pointer-events-none text-[#a6927a]">
              <Search className="w-4 h-4" />
            </div>

            <input
              type="text"
              value={searchQuery}
              onChange={(e) => {
                onSearchChange(e.target.value);
                if (activeNav !== "search" && e.target.value.trim()) {
                  onNavChange("search");
                }
              }}
              placeholder="Search movies, sagas, documentaries, lore..."
              className="w-full py-2 pr-10 bg-transparent text-xs sm:text-sm text-[#f8f5ee] placeholder-[#806f5e] focus:outline-none font-serif tracking-wide"
            />

            {searchQuery && (
              <button
                onClick={() => onSearchChange("")}
                className="absolute right-3 p-1 rounded-full hover:bg-[#342418] text-[#a6927a] hover:text-[#f8f5ee]"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Category Chips Bar */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          <button
            onClick={() => onSelectCategory(null)}
            className={`px-3 py-1 rounded-full font-serif shrink-0 transition-all ${
              selectedCategory === null
                ? "bg-gradient-to-r from-[#9b7536] to-[#c7983e] text-[#140e06] font-bold shadow-sm"
                : "bg-[#201812] text-[#bcaaa0] hover:bg-[#2b2018] border border-[#3d2c20]"
            }`}
          >
            All Reels
          </button>
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => onSelectCategory(cat.slug)}
              className={`px-3 py-1 rounded-full font-serif shrink-0 transition-all ${
                selectedCategory === cat.slug
                  ? "bg-gradient-to-r from-[#9b7536] to-[#c7983e] text-[#140e06] font-bold shadow-sm"
                  : "bg-[#201812] text-[#bcaaa0] hover:bg-[#2b2018] border border-[#3d2c20]"
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>
      </div>
    </header>
  );
}
