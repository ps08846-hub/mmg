"use client";

import React from "react";
import { VideoItem } from "@/types";
import { Play, Bookmark, Clock, Eye, Film } from "lucide-react";

interface ShivaayVideoCardProps {
  video: VideoItem;
  onPlay: (video: VideoItem) => void;
  isSaved: boolean;
  onToggleSave: (videoId: number, e: React.MouseEvent) => void;
}

export function ShivaayVideoCard({
  video,
  onPlay,
  isSaved,
  onToggleSave,
}: ShivaayVideoCardProps) {
  const formatViews = (count: number) => {
    if (count >= 1000) {
      return `${(count / 1000).toFixed(1)}k views`;
    }
    return `${count} views`;
  };

  return (
    <div
      onClick={() => onPlay(video)}
      className="group relative rounded-2xl overflow-hidden bg-[#1d1611] border border-[#483526] hover:border-[#a9813b] transition-all duration-300 hover:shadow-2xl flex flex-col justify-between cursor-pointer transform hover:-translate-y-1"
    >
      {/* Thumbnail Container */}
      <div className="relative aspect-video w-full overflow-hidden bg-black/50">
        <img
          src={video.thumbnailUrl}
          alt={video.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-108"
          loading="lazy"
        />

        {/* Gradient vignette */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/30 pointer-events-none" />

        {/* Duration badge */}
        <div className="absolute bottom-2 right-2 px-2 py-0.5 rounded bg-black/80 backdrop-blur-sm border border-stone-800 text-[10px] font-mono font-medium text-stone-200 flex items-center gap-1">
          <Clock className="w-2.5 h-2.5" />
          <span>{video.duration}</span>
        </div>

        {/* Video type pill */}
        <div className="absolute top-2 left-2 px-2 py-0.5 rounded-full bg-[#18110c]/85 border border-amber-900/40 text-[10px] font-serif uppercase tracking-wider text-amber-300">
          {video.videoType}
        </div>

        {/* Bookmark quick button */}
        <button
          onClick={(e) => onToggleSave(video.id, e)}
          className={`absolute top-2 right-2 p-1.5 rounded-full backdrop-blur-md transition-colors ${
            isSaved
              ? "bg-amber-500/80 text-black"
              : "bg-black/60 hover:bg-black/80 text-stone-300 hover:text-white"
          }`}
          title={isSaved ? "Remove from Watchlist" : "Save to Watchlist"}
        >
          <Bookmark className={`w-3.5 h-3.5 ${isSaved ? "fill-current" : ""}`} />
        </button>

        {/* Center Hover Play Icon */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40">
          <div className="w-11 h-11 rounded-full bg-[#d4af37] text-stone-950 flex items-center justify-center shadow-lg transform scale-90 group-hover:scale-100 transition-transform">
            <Play className="w-5 h-5 fill-current ml-0.5" />
          </div>
        </div>
      </div>

      {/* Meta Information */}
      <div className="p-3.5 space-y-1.5 flex-1 flex flex-col justify-between">
        <div>
          {/* Category */}
          <div className="flex items-center justify-between text-[11px] text-[#aa9684] mb-1 font-serif">
            <span>{video.category?.name || "Cinema Showcase"}</span>
            <span className="font-mono text-[10px]">{video.releaseYear}</span>
          </div>

          {/* Title */}
          <h3 className="font-serif text-sm font-bold text-[#fcf9f2] line-clamp-2 leading-snug group-hover:text-[#f7dc78] transition-colors">
            {video.title}
          </h3>
        </div>

        {/* Footer Meta */}
        <div className="pt-2 border-t border-[#38281d] flex items-center justify-between text-[11px] text-[#8e7a68] font-mono">
          <span className="flex items-center gap-1">
            <Eye className="w-3 h-3" />
            <span>{formatViews(video.views)}</span>
          </span>
          <span className="text-amber-400 font-bold">★ {video.rating}</span>
        </div>
      </div>
    </div>
  );
}
