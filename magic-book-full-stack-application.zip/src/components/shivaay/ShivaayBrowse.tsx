"use client";

import React from "react";
import { VideoItem, CategoryItem } from "@/types";
import { ShivaayHero } from "./ShivaayHero";
import { ShivaayVideoCard } from "./ShivaayVideoCard";
import { AdMobBanner } from "../ads/AdMobBanner";
import { AdMobNativeCard } from "../ads/AdMobNativeCard";
import {
  Film,
  Sparkles,
  Clock,
  Bookmark,
  Layers,
  Flame,
  Search,
  FolderOpen,
  ArrowRight,
} from "lucide-react";

interface ShivaayBrowseProps {
  videos: VideoItem[];
  categories: CategoryItem[];
  savedVideoIds: number[];
  activeNav: string;
  searchQuery: string;
  selectedCategory: string | null;
  onSelectCategory: (slug: string | null) => void;
  onSelectVideo: (video: VideoItem) => void;
  onToggleSave: (videoId: number) => void;
  onNavChange: (nav: string) => void;
}

export function ShivaayBrowse({
  videos,
  categories,
  savedVideoIds,
  activeNav,
  searchQuery,
  selectedCategory,
  onSelectCategory,
  onSelectVideo,
  onToggleSave,
  onNavChange,
}: ShivaayBrowseProps) {
  // Filter by search query if active
  let displayedVideos = videos;

  if (searchQuery.trim()) {
    const q = searchQuery.toLowerCase().trim();
    displayedVideos = videos.filter(
      (v) =>
        v.title.toLowerCase().includes(q) ||
        v.description.toLowerCase().includes(q) ||
        v.tags.toLowerCase().includes(q) ||
        (v.category && v.category.name.toLowerCase().includes(q))
    );
  } else if (selectedCategory) {
    displayedVideos = videos.filter(
      (v) => v.category?.slug === selectedCategory
    );
  }

  // Filter lists for shelves
  const featuredVideo = videos.find((v) => v.isFeatured) || videos[0];
  const movies = videos.filter((v) => v.videoType === "movie");
  const latestVideos = [...videos].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );
  const savedVideos = videos.filter((v) => savedVideoIds.includes(v.id));

  // Render according to active navigation
  if (activeNav === "movies") {
    return (
      <div className="space-y-6 pb-24 max-w-6xl mx-auto px-4 pt-4 text-[#ede4d8]">
        <div className="border-b border-[#3e2e21] pb-3">
          <h2 className="font-serif text-2xl font-bold text-[#fcf9f2] flex items-center gap-2">
            <Film className="w-6 h-6 text-[#d4af37]" />
            <span>Movies &amp; Feature Reels</span>
          </h2>
          <p className="text-xs text-[#a99887] font-serif">
            High fidelity feature presentations and open cinema productions
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {movies.map((video) => (
            <ShivaayVideoCard
              key={video.id}
              video={video}
              onPlay={onSelectVideo}
              isSaved={savedVideoIds.includes(video.id)}
              onToggleSave={(id, e) => {
                e.stopPropagation();
                onToggleSave(id);
              }}
            />
          ))}
        </div>
      </div>
    );
  }

  if (activeNav === "latest") {
    return (
      <div className="space-y-6 pb-24 max-w-6xl mx-auto px-4 pt-4 text-[#ede4d8]">
        <div className="border-b border-[#3e2e21] pb-3">
          <h2 className="font-serif text-2xl font-bold text-[#fcf9f2] flex items-center gap-2">
            <Clock className="w-6 h-6 text-[#d4af37]" />
            <span>Latest Unveiled Releases</span>
          </h2>
          <p className="text-xs text-[#a99887] font-serif">
            Recently archived reels added to the Shivaay Library
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {latestVideos.map((video) => (
            <ShivaayVideoCard
              key={video.id}
              video={video}
              onPlay={onSelectVideo}
              isSaved={savedVideoIds.includes(video.id)}
              onToggleSave={(id, e) => {
                e.stopPropagation();
                onToggleSave(id);
              }}
            />
          ))}
        </div>
      </div>
    );
  }

  if (activeNav === "categories") {
    return (
      <div className="space-y-6 pb-24 max-w-6xl mx-auto px-4 pt-4 text-[#ede4d8]">
        <div className="border-b border-[#3e2e21] pb-3">
          <h2 className="font-serif text-2xl font-bold text-[#fcf9f2] flex items-center gap-2">
            <FolderOpen className="w-6 h-6 text-[#d4af37]" />
            <span>Cinema Categories</span>
          </h2>
          <p className="text-xs text-[#a99887] font-serif">
            Curated collections sorted by narrative genre &amp; lore
          </p>
        </div>

        {/* Categories cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => {
                onSelectCategory(cat.slug);
                onNavChange("home");
              }}
              className="p-4 rounded-2xl bg-[#1e1711] hover:bg-[#2b2017] border border-[#483525] hover:border-[#a9813b] text-left transition-all space-y-2 group"
            >
              <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 group-hover:scale-110 transition-transform">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <h4 className="font-serif text-xs sm:text-sm font-bold text-[#fdf8f0]">
                  {cat.name}
                </h4>
                <p className="text-[10px] text-stone-400 font-mono">
                  {cat.videoCount || 0} reels
                </p>
              </div>
            </button>
          ))}
        </div>

        <div className="pt-4">
          <AdMobNativeCard />
        </div>
      </div>
    );
  }

  if (activeNav === "saved") {
    return (
      <div className="space-y-6 pb-24 max-w-6xl mx-auto px-4 pt-4 text-[#ede4d8]">
        <div className="border-b border-[#3e2e21] pb-3">
          <h2 className="font-serif text-2xl font-bold text-[#fcf9f2] flex items-center gap-2">
            <Bookmark className="w-6 h-6 text-[#d4af37] fill-amber-400" />
            <span>My Saved Reels &amp; Watchlist</span>
          </h2>
          <p className="text-xs text-[#a99887] font-serif">
            Personal bookmark archive of videos you saved to watch
          </p>
        </div>

        {savedVideos.length === 0 ? (
          <div className="text-center py-20 px-4 rounded-3xl border border-dashed border-[#4d3a2c] bg-[#1a130e]/50 text-[#b6a492] space-y-3">
            <Bookmark className="w-12 h-12 text-[#9e8354] mx-auto opacity-50" />
            <h3 className="font-serif text-lg font-bold text-[#ede3d5]">
              Your Watchlist is Empty
            </h3>
            <p className="text-xs text-[#9c8975] max-w-sm mx-auto font-serif">
              Save any movie or documentary by tapping the bookmark ribbon on the video card.
            </p>
            <button
              onClick={() => onNavChange("home")}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#9b7536] to-[#c7983e] text-[#140e06] font-serif font-bold text-xs"
            >
              Explore Library
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {savedVideos.map((video) => (
              <ShivaayVideoCard
                key={video.id}
                video={video}
                onPlay={onSelectVideo}
                isSaved={true}
                onToggleSave={(id, e) => {
                  e.stopPropagation();
                  onToggleSave(id);
                }}
              />
            ))}
          </div>
        )}
      </div>
    );
  }

  if (searchQuery.trim() || selectedCategory) {
    return (
      <div className="space-y-6 pb-24 max-w-6xl mx-auto px-4 pt-4 text-[#ede4d8]">
        <div className="flex items-center justify-between border-b border-[#3e2e21] pb-3">
          <div>
            <h2 className="font-serif text-xl sm:text-2xl font-bold text-[#fcf9f2] flex items-center gap-2">
              <Search className="w-5 h-5 text-[#d4af37]" />
              <span>
                {selectedCategory
                  ? `Category: ${categories.find((c) => c.slug === selectedCategory)?.name || selectedCategory}`
                  : `Search Results: "${searchQuery}"`}
              </span>
            </h2>
            <p className="text-xs text-[#a99887] font-serif font-mono">
              {displayedVideos.length} {displayedVideos.length === 1 ? "reel" : "reels"} discovered
            </p>
          </div>

          {(searchQuery || selectedCategory) && (
            <button
              onClick={() => {
                onSelectCategory(null);
                onNavChange("home");
              }}
              className="text-xs text-[#d4af37] hover:underline font-serif"
            >
              Clear Filter
            </button>
          )}
        </div>

        {displayedVideos.length === 0 ? (
          <div className="text-center py-20 px-4 rounded-3xl border border-dashed border-[#4d3a2c] bg-[#1a130e]/50 text-[#b6a492] space-y-3">
            <Film className="w-12 h-12 text-[#9e8354] mx-auto opacity-50" />
            <h3 className="font-serif text-lg font-bold text-[#ede3d5]">
              No Reels Found
            </h3>
            <p className="text-xs text-[#9c8975] max-w-sm mx-auto font-serif">
              No videos matched your criteria. Try adjusting your query or exploring our featured collections.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {displayedVideos.map((video) => (
              <ShivaayVideoCard
                key={video.id}
                video={video}
                onPlay={onSelectVideo}
                isSaved={savedVideoIds.includes(video.id)}
                onToggleSave={(id, e) => {
                  e.stopPropagation();
                  onToggleSave(id);
                }}
              />
            ))}
          </div>
        )}
      </div>
    );
  }

  // DEFAULT HOME VIEW
  return (
    <div className="space-y-8 pb-24 max-w-6xl mx-auto px-4 pt-3 text-[#ede4d8]">
      {/* Featured Hero Banner */}
      {featuredVideo && (
        <ShivaayHero
          video={featuredVideo}
          onPlay={onSelectVideo}
          isSaved={savedVideoIds.includes(featuredVideo.id)}
          onToggleSave={onToggleSave}
        />
      )}

      {/* Movies & Epic Sagas Shelf */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Flame className="w-4 h-4 text-[#d4af37]" />
            <h3 className="font-serif text-base sm:text-lg font-bold text-[#fcf9f2]">
              Epic Sagas &amp; Feature Films
            </h3>
          </div>
          <button
            onClick={() => onNavChange("movies")}
            className="text-xs text-[#d4af37] hover:underline font-serif flex items-center gap-1"
          >
            <span>See All</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {movies.slice(0, 3).map((video) => (
            <ShivaayVideoCard
              key={video.id}
              video={video}
              onPlay={onSelectVideo}
              isSaved={savedVideoIds.includes(video.id)}
              onToggleSave={(id, e) => {
                e.stopPropagation();
                onToggleSave(id);
              }}
            />
          ))}
        </div>
      </section>

      {/* Latest Releases Shelf */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-[#d4af37]" />
            <h3 className="font-serif text-base sm:text-lg font-bold text-[#fcf9f2]">
              Recently Unveiled
            </h3>
          </div>
          <button
            onClick={() => onNavChange("latest")}
            className="text-xs text-[#d4af37] hover:underline font-serif flex items-center gap-1"
          >
            <span>See All</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {latestVideos.slice(0, 6).map((video) => (
            <ShivaayVideoCard
              key={video.id}
              video={video}
              onPlay={onSelectVideo}
              isSaved={savedVideoIds.includes(video.id)}
              onToggleSave={(id, e) => {
                e.stopPropagation();
                onToggleSave(id);
              }}
            />
          ))}
        </div>
      </section>

      {/* AdMob Compliant Slot */}
      <section className="pt-2">
        <AdMobBanner placement="inline" />
      </section>
    </div>
  );
}
