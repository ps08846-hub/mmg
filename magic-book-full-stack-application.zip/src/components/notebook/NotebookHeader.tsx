"use client";

import React, { useState, useEffect } from "react";
import { Search, Feather, Sparkles, Plus, BookOpen, KeyRound, X } from "lucide-react";
import { sounds } from "@/lib/sound";

interface NotebookHeaderProps {
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onOpenNewNote: () => void;
  onUnlockShivaay: () => void;
  currentTab: string;
  onTabChange: (tab: string) => void;
}

export function NotebookHeader({
  searchQuery,
  onSearchChange,
  onOpenNewNote,
  onUnlockShivaay,
  currentTab,
  onTabChange,
}: NotebookHeaderProps) {
  const [showSecretHint, setShowSecretHint] = useState(false);
  const [isSecretGlowing, setIsSecretGlowing] = useState(false);

  // Check for the sacred trigger "SHIVAAY"
  useEffect(() => {
    const trimmed = searchQuery.trim().toUpperCase();
    if (trimmed === "SHIVAAY") {
      setIsSecretGlowing(true);
      sounds.playShivaayUnlock();
      const timer = setTimeout(() => {
        onUnlockShivaay();
      }, 450);
      return () => clearTimeout(timer);
    } else {
      setIsSecretGlowing(false);
    }
  }, [searchQuery, onUnlockShivaay]);

  return (
    <header className="sticky top-0 z-30 bg-[#1c1713]/95 backdrop-blur-md border-b border-[#3d2f24] text-[#ede3d5] shadow-lg">
      <div className="max-w-5xl mx-auto px-4 py-3">
        {/* Top Brand Bar */}
        <div className="flex items-center justify-between gap-3 mb-2.5">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#8d6c38] via-[#d4af37] to-[#59411d] p-0.5 shadow-md flex items-center justify-center">
              <div className="w-full h-full bg-[#201813] rounded-[10px] flex items-center justify-center">
                <Feather className="w-5 h-5 text-[#f4d68c]" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h1 className="font-serif text-lg font-bold tracking-tight text-[#fdf8f0]">
                  Magic Book
                </h1>
                <span className="text-[10px] uppercase font-mono px-1.5 py-0.2 bg-[#d4af37]/20 text-[#f5d88f] rounded border border-[#d4af37]/40">
                  Journal
                </span>
              </div>
              <p className="text-[11px] text-[#b8a794] hidden sm:block">
                Handwritten sanctuary for thoughts & secrets
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Secret Clue Trigger for discovery */}
            <button
              onClick={() => setShowSecretHint(!showSecretHint)}
              className="p-2 rounded-lg bg-[#2a211a] hover:bg-[#382b22] border border-[#48372b] text-[#d4af37] text-xs flex items-center gap-1.5 transition-all"
              title="Secret Seal Hint"
              aria-label="Secret Hint"
            >
              <KeyRound className="w-4 h-4 text-[#e7be4c]" />
              <span className="hidden sm:inline text-xs font-serif">Sacred Seal</span>
            </button>

            {/* Quick Create Note Button */}
            <button
              onClick={() => {
                sounds.playPageTurn();
                onOpenNewNote();
              }}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#a27b3b] via-[#cf9e42] to-[#b38437] hover:brightness-110 active:scale-95 text-[#1e150a] font-serif font-semibold text-xs sm:text-sm shadow-md flex items-center gap-1.5 transition-all"
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              <span>New Page</span>
            </button>
          </div>
        </div>

        {/* Search Bar - Core Feature */}
        <div className="relative">
          <div
            className={`relative flex items-center rounded-xl bg-[#281f18] border transition-all duration-300 ${
              isSecretGlowing
                ? "border-[#d4af37] ring-4 ring-[#d4af37]/40 shadow-[0_0_25px_rgba(212,175,55,0.6)]"
                : "border-[#4a3a2d] focus-within:border-[#c59c44] focus-within:ring-2 focus-within:ring-[#c59c44]/30"
            }`}
          >
            <div className="pl-3.5 pr-2 flex items-center pointer-events-none text-[#b8a287]">
              {isSecretGlowing ? (
                <Sparkles className="w-5 h-5 text-[#f7dc78] animate-spin" />
              ) : (
                <Search className="w-4 h-4" />
              )}
            </div>

            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Search your notes or whisper sacred words..."
              className="w-full py-2.5 pr-10 bg-transparent text-sm text-[#f8f5ee] placeholder-[#8e7a68] focus:outline-none font-serif tracking-wide"
              aria-label="Search notes"
            />

            {searchQuery && (
              <button
                onClick={() => onSearchChange("")}
                className="absolute right-3 p-1 rounded-full hover:bg-[#3d2e23] text-[#b8a287] hover:text-[#f8f5ee] transition-colors"
                title="Clear search"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Hint Dropdown */}
          {showSecretHint && (
            <div className="absolute top-full left-0 right-0 mt-2 p-3 bg-[#231b15] border border-[#d4af37]/40 rounded-xl shadow-2xl z-40 text-xs text-[#dcd2c4] animate-in fade-in slide-in-from-top-1">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2 text-[#e2b947] font-serif font-bold text-sm">
                  <Sparkles className="w-4 h-4" />
                  <span>The Whispered Mantra</span>
                </div>
                <button
                  onClick={() => setShowSecretHint(false)}
                  className="text-[#9e8874] hover:text-white"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
              <p className="mt-1.5 leading-relaxed text-[#c6b6a2]">
                Legend whispers that this book holds a secret realm hidden beneath its pages.
                Type the sacred keyword <span className="font-mono font-bold text-[#f7dc78] bg-[#3a2c20] px-1.5 py-0.5 rounded border border-[#8a6828]">SHIVAAY</span> into the search bar above to unlock the Enchanted Cinema Library!
              </p>
              <div className="mt-2.5 flex items-center justify-between">
                <button
                  onClick={() => {
                    onSearchChange("SHIVAAY");
                    setShowSecretHint(false);
                  }}
                  className="text-[11px] font-serif px-2.5 py-1 rounded bg-[#8a6a2a] text-[#fff6df] hover:brightness-110 flex items-center gap-1 font-semibold"
                >
                  <KeyRound className="w-3 h-3" />
                  <span>Auto-fill "SHIVAAY"</span>
                </button>
                <span className="text-[10px] text-[#9a8570] italic">Case-insensitive</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
