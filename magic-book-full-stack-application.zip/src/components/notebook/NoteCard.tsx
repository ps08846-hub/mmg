"use client";

import React from "react";
import { NoteItem, PaperStyle } from "@/types";
import { Pin, Trash2, Edit3, Calendar, Tag } from "lucide-react";
import { sounds } from "@/lib/sound";

interface NoteCardProps {
  note: NoteItem;
  onSelect: (note: NoteItem) => void;
  onTogglePin: (note: NoteItem, e: React.MouseEvent) => void;
  onDelete: (id: number, e: React.MouseEvent) => void;
}

const COLOR_MAP: Record<string, { border: string; accent: string; headerBg: string; ink: string }> = {
  amber: { border: "border-amber-700/30", accent: "#d4af37", headerBg: "bg-amber-950/15", ink: "text-amber-950" },
  emerald: { border: "border-emerald-700/30", accent: "#10b981", headerBg: "bg-emerald-950/15", ink: "text-emerald-950" },
  rose: { border: "border-rose-700/30", accent: "#f43f5e", headerBg: "bg-rose-950/15", ink: "text-rose-950" },
  sky: { border: "border-sky-700/30", accent: "#0284c7", headerBg: "bg-sky-950/15", ink: "text-sky-950" },
  indigo: { border: "border-indigo-700/30", accent: "#6366f1", headerBg: "bg-indigo-950/15", ink: "text-indigo-950" },
  stone: { border: "border-stone-600/30", accent: "#78716c", headerBg: "bg-stone-900/15", ink: "text-stone-900" },
};

export function NoteCard({ note, onSelect, onTogglePin, onDelete }: NoteCardProps) {
  const tags: string[] = (() => {
    try {
      return JSON.parse(note.tags);
    } catch {
      return [];
    }
  })();

  const colorStyle = COLOR_MAP[note.color] || COLOR_MAP.amber;

  const getPaperClass = (style: PaperStyle) => {
    switch (style) {
      case "ruled":
        return "paper-ruled";
      case "grid":
        return "paper-grid";
      case "parchment":
        return "paper-parchment";
      case "dark-scribe":
        return "paper-dark-scribe";
      default:
        return "bg-[#fcfaf5]";
    }
  };

  const isDarkPaper = note.paperStyle === "dark-scribe";

  const formatDate = (dateStr: string) => {
    try {
      const d = new Date(dateStr);
      return d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
    } catch {
      return "";
    }
  };

  return (
    <article
      onClick={() => {
        sounds.playPageTurn();
        onSelect(note);
      }}
      className={`group relative rounded-2xl border ${colorStyle.border} ${getPaperClass(
        note.paperStyle
      )} p-5 shadow-sm hover:shadow-xl transition-all duration-300 cursor-pointer overflow-hidden flex flex-col justify-between min-h-[220px] transform hover:-translate-y-1`}
    >
      {/* Top paper strip / folded corner visual */}
      <div className="absolute top-0 right-0 w-8 h-8 bg-gradient-to-bl from-black/15 to-transparent pointer-events-none" />

      {/* Pin Thumbtack / Marker */}
      {note.isPinned && (
        <div className="absolute -top-1 left-6 z-10">
          <div className="w-5 h-6 bg-gradient-to-b from-amber-400 to-amber-600 rounded-b-sm shadow-md flex items-center justify-center border-t-2 border-amber-300">
            <Pin className="w-3 h-3 text-[#1f1508] rotate-45" />
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="space-y-2">
        <div className="flex items-start justify-between gap-2 pt-1">
          <h3
            className={`font-serif text-base font-bold line-clamp-2 leading-snug tracking-tight ${
              isDarkPaper ? "text-[#f3eee4]" : "text-[#28201a]"
            }`}
          >
            {note.title || "Untitled Page"}
          </h3>

          <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 shrink-0">
            <button
              onClick={(e) => {
                e.stopPropagation();
                onTogglePin(note, e);
              }}
              className={`p-1.5 rounded-lg transition-colors ${
                note.isPinned
                  ? "text-amber-500 hover:bg-amber-500/10"
                  : "text-stone-400 hover:text-stone-700 hover:bg-black/5"
              }`}
              title={note.isPinned ? "Unpin note" : "Pin to desk"}
            >
              <Pin className={`w-3.5 h-3.5 ${note.isPinned ? "fill-amber-500" : ""}`} />
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onDelete(note.id, e);
              }}
              className="p-1.5 rounded-lg text-stone-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
              title="Discard page"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Content snippet */}
        <p
          className={`text-xs font-serif leading-relaxed line-clamp-4 ${
            isDarkPaper ? "text-[#d1c7b8]" : "text-[#473b30]"
          }`}
        >
          {note.content || "Empty page... tap to inscribe thoughts."}
        </p>
      </div>

      {/* Footer Meta */}
      <div className="mt-4 pt-3 border-t border-black/10 flex items-center justify-between gap-2 text-[11px]">
        <div className="flex items-center gap-1.5 flex-wrap">
          {tags.slice(0, 2).map((t, i) => (
            <span
              key={i}
              className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-sans font-medium ${
                isDarkPaper
                  ? "bg-stone-800 text-stone-300 border border-stone-700"
                  : "bg-[#291f16]/8 text-[#544131] border border-black/5"
              }`}
            >
              <Tag className="w-2.5 h-2.5 opacity-60" />
              <span>{t}</span>
            </span>
          ))}
          {tags.length > 2 && (
            <span className="text-[10px] text-stone-500">+{tags.length - 2}</span>
          )}
        </div>

        <div className="flex items-center gap-1 text-stone-400 shrink-0 font-sans text-[10px]">
          <Calendar className="w-3 h-3 opacity-70" />
          <span>{formatDate(note.updatedAt)}</span>
        </div>
      </div>
    </article>
  );
}
