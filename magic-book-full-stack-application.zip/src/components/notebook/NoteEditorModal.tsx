"use client";

import React, { useState, useEffect } from "react";
import { NoteItem, PaperStyle, NoteColor } from "@/types";
import { X, Pin, Save, Trash2, Tag, Check, Sparkles } from "lucide-react";
import { sounds } from "@/lib/sound";

interface NoteEditorModalProps {
  note: NoteItem | null; // null means creating new
  isOpen: boolean;
  onClose: () => void;
  onSave: (noteData: {
    id?: number;
    title: string;
    content: string;
    paperStyle: PaperStyle;
    color: NoteColor;
    tags: string[];
    isPinned: boolean;
  }) => Promise<void>;
  onDelete?: (id: number) => Promise<void>;
}

const PAPER_STYLES: { id: PaperStyle; label: string; desc: string }[] = [
  { id: "ruled", label: "Ruled", desc: "Classic lines" },
  { id: "parchment", label: "Parchment", desc: "Aged warm texture" },
  { id: "grid", label: "Grid", desc: "Blueprint grid" },
  { id: "blank", label: "Blank", desc: "Pure ivory" },
  { id: "dark-scribe", label: "Dark Scribe", desc: "Night ink" },
];

const COLORS: { id: NoteColor; label: string; bg: string }[] = [
  { id: "amber", label: "Warm Gold", bg: "bg-amber-500" },
  { id: "emerald", label: "Sage Green", bg: "bg-emerald-600" },
  { id: "rose", label: "Rose Petal", bg: "bg-rose-500" },
  { id: "sky", label: "Mountain Sky", bg: "bg-sky-600" },
  { id: "indigo", label: "Dusk Indigo", bg: "bg-indigo-600" },
  { id: "stone", label: "Monk Stone", bg: "bg-stone-600" },
];

const PRESET_TAGS = ["Journal", "Lore", "Ideas", "Sacred", "Routine", "Travel", "Shivaay"];

export function NoteEditorModal({
  note,
  isOpen,
  onClose,
  onSave,
  onDelete,
}: NoteEditorModalProps) {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [paperStyle, setPaperStyle] = useState<PaperStyle>("ruled");
  const [color, setColor] = useState<NoteColor>("amber");
  const [isPinned, setIsPinned] = useState(false);
  const [tags, setTags] = useState<string[]>([]);
  const [tagInput, setTagInput] = useState("");
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (note) {
      setTitle(note.title);
      setContent(note.content);
      setPaperStyle(note.paperStyle);
      setColor(note.color);
      setIsPinned(note.isPinned);
      try {
        setTags(JSON.parse(note.tags) || []);
      } catch {
        setTags([]);
      }
    } else {
      setTitle("");
      setContent("");
      setPaperStyle("ruled");
      setColor("amber");
      setIsPinned(false);
      setTags(["Journal"]);
    }
    setTagInput("");
  }, [note, isOpen]);

  if (!isOpen) return null;

  const handleAddTag = (t: string) => {
    const clean = t.trim();
    if (clean && !tags.includes(clean)) {
      setTags([...tags, clean]);
    }
    setTagInput("");
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter((t) => t !== tagToRemove));
  };

  const handleSave = async () => {
    if (!title.trim() && !content.trim()) {
      alert("Please enter a title or note content.");
      return;
    }

    try {
      setIsSaving(true);
      await onSave({
        id: note?.id,
        title: title.trim() || "Untitled Inscription",
        content,
        paperStyle,
        color,
        tags,
        isPinned,
      });
      sounds.playPageTurn();
      onClose();
    } catch (err) {
      console.error(err);
      alert("Failed to save note");
    } finally {
      setIsSaving(false);
    }
  };

  const wordCount = content.trim() ? content.trim().split(/\s+/).length : 0;
  const isDarkPaper = paperStyle === "dark-scribe";

  const getPaperBg = () => {
    switch (paperStyle) {
      case "ruled":
        return "paper-ruled";
      case "grid":
        return "paper-grid";
      case "parchment":
        return "paper-parchment";
      case "dark-scribe":
        return "paper-dark-scribe";
      default:
        return "bg-[#fcfaf4]";
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className={`w-full max-w-3xl max-h-[92vh] flex flex-col rounded-2xl shadow-2xl border border-amber-900/40 overflow-hidden ${
          isDarkPaper ? "bg-[#191512] text-[#f2ece1]" : "bg-[#fcfbf7] text-[#2c221a]"
        }`}
      >
        {/* Top Control Bar */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-black/10 bg-[#241c16] text-[#ede3d5] shrink-0">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsPinned(!isPinned)}
              className={`p-1.5 rounded-lg border transition-all ${
                isPinned
                  ? "bg-amber-500/20 text-amber-300 border-amber-500/40"
                  : "bg-black/20 text-stone-400 border-stone-700 hover:text-white"
              }`}
              title={isPinned ? "Pinned to Desk" : "Pin Note"}
            >
              <Pin className={`w-4 h-4 ${isPinned ? "fill-amber-400 rotate-45" : ""}`} />
            </button>

            {/* Paper Texture Selector */}
            <div className="hidden sm:flex items-center gap-1 bg-[#1a1410] p-0.5 rounded-lg border border-stone-800 text-xs">
              {PAPER_STYLES.map((ps) => (
                <button
                  key={ps.id}
                  onClick={() => setPaperStyle(ps.id)}
                  className={`px-2.5 py-1 rounded-md transition-all font-serif ${
                    paperStyle === ps.id
                      ? "bg-amber-600/30 text-amber-200 font-semibold"
                      : "text-stone-400 hover:text-stone-200"
                  }`}
                >
                  {ps.label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2">
            {note && onDelete && (
              <button
                onClick={async () => {
                  if (confirm("Burn this page from your notebook?")) {
                    await onDelete(note.id);
                    onClose();
                  }
                }}
                className="p-1.5 text-rose-400 hover:text-rose-300 hover:bg-rose-950/40 rounded-lg transition-colors"
                title="Delete note"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}

            <button
              onClick={handleSave}
              disabled={isSaving}
              className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-[#a27b3b] via-[#cf9e42] to-[#b38437] hover:brightness-110 text-[#191107] font-serif font-bold text-xs sm:text-sm shadow-md flex items-center gap-1.5 transition-all disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              <span>{isSaving ? "Inscribing..." : "Save Page"}</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-stone-400 hover:text-white rounded-lg hover:bg-stone-800 transition-colors"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Mobile Paper Style Selector */}
        <div className="sm:hidden px-3 py-1.5 bg-[#1d1611] border-b border-stone-800 flex items-center gap-1 overflow-x-auto text-xs shrink-0">
          <span className="text-[10px] text-stone-400 uppercase font-mono mr-1">Style:</span>
          {PAPER_STYLES.map((ps) => (
            <button
              key={ps.id}
              onClick={() => setPaperStyle(ps.id)}
              className={`px-2 py-0.5 rounded text-[11px] font-serif shrink-0 ${
                paperStyle === ps.id
                  ? "bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30"
                  : "text-stone-400"
              }`}
            >
              {ps.label}
            </button>
          ))}
        </div>

        {/* Editor Body */}
        <div
          className={`flex-1 p-5 sm:p-8 overflow-y-auto ${getPaperBg()} transition-colors flex flex-col`}
        >
          {/* Note Title Input */}
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Title of this page..."
            className={`w-full text-xl sm:text-2xl font-serif font-bold tracking-tight bg-transparent border-b pb-2 mb-4 focus:outline-none transition-colors ${
              isDarkPaper
                ? "text-[#f8f5ee] border-stone-700/80 placeholder-stone-500 focus:border-amber-500/60"
                : "text-[#241c14] border-stone-300/80 placeholder-stone-400 focus:border-amber-800/60"
            }`}
          />

          {/* Note Content Textarea */}
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Inscribe your thoughts, sketches, meditations..."
            className={`w-full flex-1 min-h-[280px] bg-transparent resize-none font-serif text-sm sm:text-base leading-[32px] focus:outline-none ${
              isDarkPaper
                ? "text-[#ded5c7] placeholder-stone-500"
                : "text-[#2e241c] placeholder-stone-400"
            }`}
            style={{
              lineHeight: paperStyle === "ruled" || paperStyle === "parchment" ? "32px" : "1.6",
            }}
          />

          {/* Tags & Palette Shelf */}
          <div className="mt-4 pt-4 border-t border-black/10 shrink-0 space-y-3">
            {/* Color Tint Selector */}
            <div className="flex items-center gap-2 flex-wrap">
              <span
                className={`text-[11px] font-mono uppercase tracking-wider ${
                  isDarkPaper ? "text-stone-400" : "text-stone-600"
                }`}
              >
                Color Tint:
              </span>
              <div className="flex items-center gap-1.5">
                {COLORS.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => setColor(c.id)}
                    className={`w-5 h-5 rounded-full ${c.bg} flex items-center justify-center transition-transform ${
                      color === c.id ? "scale-125 ring-2 ring-amber-400" : "opacity-70 hover:opacity-100"
                    }`}
                    title={c.label}
                  >
                    {color === c.id && <Check className="w-3 h-3 text-white" />}
                  </button>
                ))}
              </div>
            </div>

            {/* Tag Management */}
            <div className="flex items-center gap-2 flex-wrap">
              <span
                className={`text-[11px] font-mono uppercase tracking-wider ${
                  isDarkPaper ? "text-stone-400" : "text-stone-600"
                }`}
              >
                Tags:
              </span>
              {tags.map((t) => (
                <span
                  key={t}
                  className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs bg-amber-500/15 text-amber-900 border border-amber-500/30 font-serif"
                >
                  <Tag className="w-2.5 h-2.5" />
                  <span>{t}</span>
                  <button
                    onClick={() => handleRemoveTag(t)}
                    className="hover:text-rose-600 ml-0.5"
                  >
                    ×
                  </button>
                </span>
              ))}

              <div className="inline-flex items-center gap-1">
                <input
                  type="text"
                  value={tagInput}
                  onChange={(e) => setTagInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      handleAddTag(tagInput);
                    }
                  }}
                  placeholder="+ Add tag..."
                  className="text-xs px-2 py-0.5 rounded bg-black/5 border border-black/10 focus:outline-none w-24"
                />
              </div>

              {/* Suggestions */}
              <div className="flex items-center gap-1 ml-auto text-[11px] text-stone-500">
                {PRESET_TAGS.filter((pt) => !tags.includes(pt))
                  .slice(0, 3)
                  .map((pt) => (
                    <button
                      key={pt}
                      onClick={() => handleAddTag(pt)}
                      className="hover:text-amber-600 underline decoration-dotted"
                    >
                      +{pt}
                    </button>
                  ))}
              </div>
            </div>
          </div>
        </div>

        {/* Footer Meta */}
        <div className="px-4 py-2 border-t border-black/10 bg-[#211913] text-[#a89582] text-[11px] flex items-center justify-between font-mono shrink-0">
          <div className="flex items-center gap-3">
            <span>{wordCount} words</span>
            <span>{content.length} characters</span>
          </div>
          <span className="italic font-serif">Magic Book Scribe v2.5</span>
        </div>
      </div>
    </div>
  );
}
