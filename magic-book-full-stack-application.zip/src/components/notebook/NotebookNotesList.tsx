"use client";

import React, { useState } from "react";
import { NoteItem } from "@/types";
import { NoteCard } from "./NoteCard";
import { Search, Tag, Filter, SortDesc, Plus, Feather, FolderOpen } from "lucide-react";

interface NotebookNotesListProps {
  notes: NoteItem[];
  onSelectNote: (note: NoteItem) => void;
  onOpenNewNote: () => void;
  onTogglePin: (note: NoteItem, e: React.MouseEvent) => void;
  onDeleteNote: (id: number, e: React.MouseEvent) => void;
  searchQuery: string;
}

export function NotebookNotesList({
  notes,
  onSelectNote,
  onOpenNewNote,
  onTogglePin,
  onDeleteNote,
  searchQuery,
}: NotebookNotesListProps) {
  const [selectedTag, setSelectedTag] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<"updated" | "title" | "pinned">("updated");

  // Extract all unique tags
  const allTags = Array.from(
    new Set(
      notes.flatMap((n) => {
        try {
          return JSON.parse(n.tags) as string[];
        } catch {
          return [];
        }
      })
    )
  );

  // Filter notes
  const filtered = notes.filter((n) => {
    if (selectedTag) {
      try {
        const parsedTags = JSON.parse(n.tags) as string[];
        if (!parsedTags.includes(selectedTag)) return false;
      } catch {
        return false;
      }
    }
    return true;
  });

  // Sort notes
  const sorted = [...filtered].sort((a, b) => {
    if (sortBy === "pinned") {
      if (a.isPinned && !b.isPinned) return -1;
      if (!a.isPinned && b.isPinned) return 1;
      return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
    }
    if (sortBy === "title") {
      return a.title.localeCompare(b.title);
    }
    return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
  });

  return (
    <div className="space-y-5 pb-24 max-w-5xl mx-auto px-4 pt-4">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#3d2e23] pb-4">
        <div>
          <h2 className="font-serif text-2xl font-bold text-[#fcf9f2] flex items-center gap-2">
            <FolderOpen className="w-6 h-6 text-[#d4af37]" />
            <span>All Journal Archives</span>
          </h2>
          <p className="text-xs text-[#b8a490] font-serif">
            Browse, categorize and search through every handwritten leaf
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Sort Selector */}
          <div className="flex items-center gap-1 bg-[#231b15] border border-[#48372a] rounded-xl px-2.5 py-1 text-xs text-[#dcd1c2]">
            <SortDesc className="w-3.5 h-3.5 text-[#d4af37]" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as "updated" | "title" | "pinned")}
              className="bg-transparent focus:outline-none text-xs font-serif cursor-pointer"
            >
              <option value="updated" className="bg-[#231b15]">Latest Inscription</option>
              <option value="pinned" className="bg-[#231b15]">Pinned First</option>
              <option value="title" className="bg-[#231b15]">Title (A-Z)</option>
            </select>
          </div>

          <button
            onClick={onOpenNewNote}
            className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-[#8a6828] to-[#c7983e] text-[#1c1409] font-serif font-bold text-xs shadow flex items-center gap-1"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Page</span>
          </button>
        </div>
      </div>

      {/* Tags Bar */}
      {allTags.length > 0 && (
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          <span className="text-[11px] text-[#9c8975] font-serif uppercase tracking-wider shrink-0 flex items-center gap-1 mr-1">
            <Tag className="w-3 h-3" />
            <span>Tags:</span>
          </span>
          <button
            onClick={() => setSelectedTag(null)}
            className={`px-2.5 py-0.5 rounded-full text-xs font-serif shrink-0 transition-all ${
              selectedTag === null
                ? "bg-[#d4af37]/20 text-[#f7dc78] font-bold border border-[#d4af37]/50"
                : "bg-[#211a14] text-[#b4a290] border border-[#3d2e23] hover:text-white"
            }`}
          >
            All
          </button>
          {allTags.map((t) => (
            <button
              key={t}
              onClick={() => setSelectedTag(selectedTag === t ? null : t)}
              className={`px-2.5 py-0.5 rounded-full text-xs font-serif shrink-0 transition-all ${
                selectedTag === t
                  ? "bg-[#d4af37]/20 text-[#f7dc78] font-bold border border-[#d4af37]/50"
                  : "bg-[#211a14] text-[#b4a290] border border-[#3d2e23] hover:text-white"
              }`}
            >
              #{t}
            </button>
          ))}
        </div>
      )}

      {/* Search status if query active */}
      {searchQuery && (
        <div className="p-2.5 rounded-xl bg-[#281f18] border border-[#48372b] text-xs text-[#dcd1c2] flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <Search className="w-3.5 h-3.5 text-[#d4af37]" />
            <span>
              Searching for: <strong className="text-[#f7dc78]">&quot;{searchQuery}&quot;</strong>
            </span>
          </div>
          <span className="text-stone-400 font-mono text-[11px]">
            {sorted.length} {sorted.length === 1 ? "match" : "matches"}
          </span>
        </div>
      )}

      {/* Grid of Notes */}
      {sorted.length === 0 ? (
        <div className="text-center py-20 px-4 rounded-3xl border border-dashed border-[#4d3a2c] bg-[#1e1712]/40 text-[#b6a492] space-y-3">
          <Feather className="w-12 h-12 text-[#9e8354] mx-auto opacity-60" />
          <h3 className="font-serif text-lg font-bold text-[#ede3d5]">
            No Inscriptions Found
          </h3>
          <p className="text-xs text-[#9c8975] max-w-sm mx-auto font-serif">
            {searchQuery
              ? `No notes match "${searchQuery}". Try different search terms or whisper "SHIVAAY" to open the secret library.`
              : "No notes are tagged with this filter. Tap below to create one."}
          </p>
          <button
            onClick={onOpenNewNote}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#8a6828] to-[#c7983e] text-[#1c1409] font-serif font-bold text-xs"
          >
            Create Note
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {sorted.map((note) => (
            <NoteCard
              key={note.id}
              note={note}
              onSelect={onSelectNote}
              onTogglePin={onTogglePin}
              onDelete={onDeleteNote}
            />
          ))}
        </div>
      )}
    </div>
  );
}
