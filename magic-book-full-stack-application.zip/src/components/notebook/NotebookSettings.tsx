"use client";

import React, { useState } from "react";
import { NoteItem } from "@/types";
import { sounds } from "@/lib/sound";
import { DEFAULT_ADMOB_CONFIG, POLICY_COMPLIANCE_NOTES } from "@/lib/admob";
import {
  Settings,
  Volume2,
  VolumeX,
  Download,
  ShieldCheck,
  Lock,
  FileText,
  Sparkles,
  Info,
  CheckCircle2,
  Smartphone,
  ExternalLink,
} from "lucide-react";

interface NotebookSettingsProps {
  notes: NoteItem[];
  onOpenAdmin: () => void;
  onUnlockShivaay: () => void;
}

export function NotebookSettings({
  notes,
  onOpenAdmin,
  onUnlockShivaay,
}: NotebookSettingsProps) {
  const [soundEnabled, setSoundEnabled] = useState(sounds.enabled);
  const [copiedStatus, setCopiedStatus] = useState<string | null>(null);

  const toggleSound = () => {
    sounds.enabled = !soundEnabled;
    setSoundEnabled(!soundEnabled);
    if (!soundEnabled) {
      sounds.playPageTurn();
    }
  };

  const handleExportJSON = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(notes, null, 2));
    const downloadAnchor = document.createElement("a");
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `magic_book_journal_backup_${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleExportText = () => {
    const textContent = notes
      .map(
        (n) =>
          `========================================\n` +
          `TITLE: ${n.title}\n` +
          `DATE: ${new Date(n.updatedAt).toLocaleString()}\n` +
          `STYLE: ${n.paperStyle}\n` +
          `----------------------------------------\n` +
          `${n.content}\n\n`
      )
      .join("\n");

    const dataStr = "data:text/plain;charset=utf-8," + encodeURIComponent(textContent);
    const downloadAnchor = document.createElement("a");
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `magic_book_manuscript_${new Date().toISOString().slice(0, 10)}.txt`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="space-y-6 pb-24 max-w-3xl mx-auto px-4 pt-4 text-[#ede4d8]">
      {/* Title */}
      <div className="border-b border-[#3d2e23] pb-4">
        <h2 className="font-serif text-2xl font-bold text-[#fcf9f2] flex items-center gap-2">
          <Settings className="w-6 h-6 text-[#d4af37]" />
          <span>Journal Settings &amp; Sanctum</span>
        </h2>
        <p className="text-xs text-[#b8a490] font-serif">
          Manage handwritten preferences, export archives, and view platform configuration
        </p>
      </div>

      {/* Scribe Sound & Sensory Settings */}
      <section className="p-5 rounded-2xl bg-[#211a14] border border-[#48372b] space-y-4 shadow-md">
        <h3 className="font-serif text-sm font-bold text-[#f7dc78] flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-[#d4af37]" />
          <span>Sensory &amp; Atmosphere</span>
        </h3>

        <div className="flex items-center justify-between py-2 border-b border-[#33251c]">
          <div>
            <p className="text-xs font-serif font-semibold text-[#f5efe6]">
              Acoustic Page Rustle &amp; Harmonics
            </p>
            <p className="text-[11px] text-[#9f8c79]">
              Synthesizes realistic paper leaf rustle and sacred bell tones via Web Audio API
            </p>
          </div>
          <button
            onClick={toggleSound}
            className={`p-2 rounded-xl border flex items-center gap-2 text-xs font-serif transition-all ${
              soundEnabled
                ? "bg-[#d4af37]/20 border-[#d4af37]/40 text-[#f7dc78]"
                : "bg-black/20 border-stone-800 text-stone-500"
            }`}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            <span>{soundEnabled ? "Active" : "Muted"}</span>
          </button>
        </div>

        <div className="flex items-center justify-between py-1">
          <div>
            <p className="text-xs font-serif font-semibold text-[#f5efe6]">
              Secret Mode Portal
            </p>
            <p className="text-[11px] text-[#9f8c79]">
              Whisper &quot;SHIVAAY&quot; in the search bar or enter directly
            </p>
          </div>
          <button
            onClick={() => {
              sounds.playShivaayUnlock();
              onUnlockShivaay();
            }}
            className="px-3 py-1.5 rounded-xl bg-[#382b20] hover:bg-[#48382a] border border-[#7a5e2a] text-[#f7dc78] font-serif text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Enter SHIVAAY</span>
          </button>
        </div>
      </section>

      {/* Export & Archival Backup */}
      <section className="p-5 rounded-2xl bg-[#211a14] border border-[#48372b] space-y-4 shadow-md">
        <h3 className="font-serif text-sm font-bold text-[#f7dc78] flex items-center gap-2">
          <Download className="w-4 h-4 text-[#d4af37]" />
          <span>Archival Export &amp; Preservation</span>
        </h3>
        <p className="text-xs text-[#bcaaa0] font-serif">
          Safeguard your thoughts. Download your full collection of {notes.length} pages anytime in open, permanent formats.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
          <button
            onClick={handleExportJSON}
            className="p-3 rounded-xl bg-[#2a2018] hover:bg-[#382b21] border border-[#503b2c] flex items-center gap-3 text-left transition-all"
          >
            <div className="w-9 h-9 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0">
              <Download className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-bold font-serif text-[#f4eee5]">Export JSON Backup</p>
              <p className="text-[10px] text-stone-400">Structured database format</p>
            </div>
          </button>

          <button
            onClick={handleExportText}
            className="p-3 rounded-xl bg-[#2a2018] hover:bg-[#382b21] border border-[#503b2c] flex items-center gap-3 text-left transition-all"
          >
            <div className="w-9 h-9 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0">
              <FileText className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-bold font-serif text-[#f4eee5]">Export Manuscript (.txt)</p>
              <p className="text-[10px] text-stone-400">Readable journal anthology</p>
            </div>
          </button>
        </div>
      </section>

      {/* Google AdMob Architecture & Play Store Compliance */}
      <section className="p-5 rounded-2xl bg-[#1d1612] border border-[#594231] space-y-3 shadow-md">
        <div className="flex items-center justify-between">
          <h3 className="font-serif text-sm font-bold text-[#f7dc78] flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-[#d4af37]" />
            <span>Google AdMob &amp; Play Store Compliance</span>
          </h3>
          <span className="px-2 py-0.5 rounded bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-[10px] font-mono font-bold flex items-center gap-1">
            <ShieldCheck className="w-3 h-3" />
            <span>Compliant</span>
          </span>
        </div>

        <p className="text-xs text-[#baa998] font-serif leading-relaxed">
          Magic Book incorporates a fully compliant advertising integration architecture designed specifically for Google Play distribution and Google AdMob policies:
        </p>

        <div className="space-y-2 pt-1 font-mono text-[11px] bg-black/40 p-3 rounded-xl border border-stone-800">
          <div className="flex items-center justify-between text-stone-300">
            <span className="text-stone-400">App ID:</span>
            <span className="text-amber-300 truncate max-w-[220px]">{DEFAULT_ADMOB_CONFIG.appId}</span>
          </div>
          <div className="flex items-center justify-between text-stone-300">
            <span className="text-stone-400">Banner Unit ID:</span>
            <span className="text-amber-300 truncate max-w-[220px]">{DEFAULT_ADMOB_CONFIG.bannerAdUnitId}</span>
          </div>
          <div className="flex items-center justify-between text-stone-300">
            <span className="text-stone-400">Interstitial Unit ID:</span>
            <span className="text-amber-300 truncate max-w-[220px]">{DEFAULT_ADMOB_CONFIG.interstitialAdUnitId}</span>
          </div>
          <div className="flex items-center justify-between text-stone-300">
            <span className="text-stone-400">Native Unit ID:</span>
            <span className="text-amber-300 truncate max-w-[220px]">{DEFAULT_ADMOB_CONFIG.nativeAdUnitId}</span>
          </div>
        </div>

        <div className="space-y-1.5 pt-2">
          {POLICY_COMPLIANCE_NOTES.map((rule, idx) => (
            <div key={idx} className="flex items-start gap-2 text-[11px] text-[#a99887]">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
              <span>{rule}</span>
            </div>
          ))}
        </div>
      </section>

      {/* Admin Doorway */}
      <section className="p-5 rounded-2xl bg-gradient-to-r from-[#2a1d15] to-[#1c130d] border border-[#6b4e33] space-y-3 shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Lock className="w-5 h-5 text-[#d4af37]" />
            <div>
              <h3 className="font-serif text-sm font-bold text-[#fcf8f0]">
                Archivist Control Chamber (Admin)
              </h3>
              <p className="text-[11px] text-[#b8a490]">
                Upload videos, configure remote storage, manage categories
              </p>
            </div>
          </div>

          <button
            onClick={onOpenAdmin}
            className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-[#8a6828] to-[#c7983e] text-[#1c1409] font-serif font-bold text-xs shadow-md hover:brightness-110 flex items-center gap-1.5 shrink-0"
          >
            <span>Open Admin</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </button>
        </div>
      </section>
    </div>
  );
}
