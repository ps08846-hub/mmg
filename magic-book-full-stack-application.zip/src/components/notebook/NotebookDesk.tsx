"use client";

import React, { useState } from "react";
import { NoteItem, PaperStyle } from "@/types";
import { NoteCard } from "./NoteCard";
import { AdMobBanner } from "../ads/AdMobBanner";
import { Feather, Pin, BookOpen, Sparkles, Plus, Clock, Search, BookMarked } from "lucide-react";
import { sounds } from "@/lib/sound";

interface NotebookDeskProps {
  notes: NoteItem[];
  onSelectNote: (note: NoteItem) => void;
  onOpenNewNote: () => void;
  onTogglePin: (note: NoteItem, e: React.MouseEvent) => void;
  onDeleteNote: (id: number, e: React.MouseEvent) => void;
  onQuickSave: (title: string, content: string) => Promise<void>;
  searchQuery: string;
}

export function NotebookDesk({
  notes,
  onSelectNote,
  onOpenNewNote,
  onTogglePin,
  onDeleteNote,
  onQuickSave,
  searchQuery,
}: NotebookDeskProps) {
  const [quickTitle, setQuickTitle] = useState("");
  const [quickContent, setQuickContent] = useState("");
  const [isQuickSaving, setIsQuickSaving] = useState(false);
  const [filterStyle, setFilterStyle] = useState<string>("all");

  const filteredNotes = notes.filter((n) => {
    if (filterStyle !== "all" && n.paperStyle !== filterStyle) return false;
    return true;
  });

  const pinnedNotes = filteredNotes.filter((n) => n.isPinned);
  const regularNotes = filteredNotes.filter((n) => !n.isPinned);

  const handleQuickCapture = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickContent.trim()) return;
    try {
      setIsQuickSaving(true);
      const title = quickTitle.trim() || `Reflection: ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
      await onQuickSave(title, quickContent.trim());
      setQuickTitle("");
      setQuickContent("");
      sounds.playPageTurn();
    } finally {
      setIsQuickSaving(false);
    }
  };

  const currentDate = new Date().toLocaleDateString("en-US", {
    weekday: "long",
    month: "long",
    day: "numeric",
    year: "numeric",
  });

  return (
    <div className="space-y-6 pb-20 max-w-5xl mx-auto px-4 pt-4">
      {/* Notebook Desk Header Cover */}
      <section className="relative rounded-3xl bg-gradient-to-r from-[#241a13] via-[#33241a] to-[#201711] border border-[#523e2f] shadow-2xl overflow-hidden p-6 sm:p-8 text-[#ede4d8]">
        {/* Leather spine stitch effect on left */}
        <div className="absolute left-0 top-0 bottom-0 w-3 bg-[#19110c] border-r border-[#694f3b] flex flex-col justify-around py-4 opacity-75">
          <span className="w-1.5 h-1.5 rounded-full bg-[#d4af37]/40 mx-auto" />
          <span className="w-1.5 h-1.5 rounded-full bg-[#d4af37]/40 mx-auto" />
          <span className="w-1.5 h-1.5 rounded-full bg-[#d4af37]/40 mx-auto" />
          <span className="w-1.5 h-1.5 rounded-full bg-[#d4af37]/40 mx-auto" />
        </div>

        {/* Decorative Watermark */}
        <div className="absolute right-4 -bottom-6 opacity-10 pointer-events-none text-amber-200">
          <BookOpen className="w-48 h-48" />
        </div>

        <div className="relative pl-3 sm:pl-4 space-y-2">
          <div className="flex items-center gap-2 text-xs font-serif text-[#d4af37]">
            <Clock className="w-3.5 h-3.5" />
            <span>{currentDate}</span>
            <span className="text-stone-500">•</span>
            <span className="italic">Vol. VII • Handwritten Sanctum</span>
          </div>

          <h2 className="font-serif text-2xl sm:text-3xl font-bold tracking-tight text-[#fcf9f2]">
            The Scribe&apos;s Desk
          </h2>

          <p className="text-xs sm:text-sm text-[#c8b9a6] max-w-xl leading-relaxed font-serif">
            Capture every spark of inspiration on realistic parchment leaves. Your journal is preserved locally and synchronised across eternity.
          </p>
        </div>

        {/* Quick Thought Interactive Blotter */}
        <form
          onSubmit={handleQuickCapture}
          className="relative mt-5 pl-3 sm:pl-4 p-3 sm:p-4 rounded-2xl bg-[#19130e]/80 border border-[#543e2e] backdrop-blur-sm shadow-inner"
        >
          <div className="flex items-center gap-2 mb-2">
            <Feather className="w-4 h-4 text-[#d4af37]" />
            <span className="text-xs font-serif font-bold text-[#f7e3b5]">
              Quick Inscription
            </span>
            <span className="text-[10px] text-stone-400 font-mono ml-auto">
              Fast Capture
            </span>
          </div>

          <input
            type="text"
            value={quickTitle}
            onChange={(e) => setQuickTitle(e.target.value)}
            placeholder="Title (optional)..."
            className="w-full text-xs font-serif bg-transparent border-b border-[#3d2c20] text-[#eee5da] placeholder-[#7d6b5b] pb-1 mb-2 focus:outline-none focus:border-[#d4af37]/50"
          />

          <textarea
            value={quickContent}
            onChange={(e) => setQuickContent(e.target.value)}
            placeholder="Jot down a quick thought, dream, or reminder before it fades..."
            rows={2}
            className="w-full text-xs sm:text-sm font-serif bg-transparent text-[#eee5da] placeholder-[#7d6b5b] resize-none focus:outline-none leading-relaxed"
          />

          <div className="flex items-center justify-between pt-2 border-t border-[#3d2c20] mt-1">
            <span className="text-[10px] text-stone-400 italic font-serif">
              Tap &quot;+ New Page&quot; for full styling &amp; textures
            </span>
            <button
              type="submit"
              disabled={!quickContent.trim() || isQuickSaving}
              className="px-3 py-1 rounded-lg bg-gradient-to-r from-[#9b7536] to-[#c7983e] hover:brightness-110 text-[#1a1207] font-serif font-bold text-xs shadow disabled:opacity-40 transition-all flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{isQuickSaving ? "Inscribing..." : "Add to Desk"}</span>
            </button>
          </div>
        </form>
      </section>

      {/* Filter Tabs by Paper Texture */}
      <div className="flex items-center justify-between gap-2 overflow-x-auto pb-1">
        <div className="flex items-center gap-1.5">
          {[
            { id: "all", label: "All Pages" },
            { id: "parchment", label: "Parchment" },
            { id: "ruled", label: "Ruled Lines" },
            { id: "grid", label: "Grid Drafts" },
            { id: "dark-scribe", label: "Dark Scribe" },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilterStyle(tab.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-serif shrink-0 transition-all ${
                filterStyle === tab.id
                  ? "bg-[#3a2c20] text-[#f7dc78] font-bold border border-[#785b2e] shadow-sm"
                  : "bg-[#211a14] text-[#b6a492] hover:bg-[#2b211a] border border-[#3d2e23]"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <span className="text-xs font-serif text-[#9e8a76] shrink-0 font-mono">
          {filteredNotes.length} {filteredNotes.length === 1 ? "page" : "pages"}
        </span>
      </div>

      {/* Pinned Notes Section */}
      {pinnedNotes.length > 0 && (
        <section className="space-y-3">
          <div className="flex items-center gap-2 text-xs font-serif font-bold text-[#f5d88f]">
            <Pin className="w-3.5 h-3.5 text-amber-400 rotate-45" />
            <span>Pinned to Desk</span>
            <span className="text-stone-500 font-mono text-[11px]">({pinnedNotes.length})</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {pinnedNotes.map((note) => (
              <NoteCard
                key={note.id}
                note={note}
                onSelect={onSelectNote}
                onTogglePin={onTogglePin}
                onDelete={onDeleteNote}
              />
            ))}
          </div>
        </section>
      )}

      {/* All / Regular Pages */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-serif font-bold text-[#ede1d1]">
            <BookMarked className="w-3.5 h-3.5 text-[#d4af37]" />
            <span>Journal Pages</span>
            <span className="text-stone-500 font-mono text-[11px]">({regularNotes.length})</span>
          </div>

          <button
            onClick={onOpenNewNote}
            className="text-xs text-[#d4af37] hover:underline font-serif flex items-center gap-1"
          >
            <span>+ Inscribe New</span>
          </button>
        </div>

        {filteredNotes.length === 0 ? (
          <div className="text-center py-16 px-4 rounded-3xl border border-dashed border-[#4d3a2c] bg-[#1e1712]/50 text-[#b6a492] space-y-3">
            <Feather className="w-10 h-10 text-amber-500/50 mx-auto" />
            <h3 className="font-serif text-lg font-bold text-[#ede3d5]">
              The Journal Awaits Your Quill
            </h3>
            <p className="text-xs text-[#9c8975] max-w-sm mx-auto font-serif">
              There are no notes in this shelf yet. Inscribe your thoughts, poetry, or daily discoveries.
            </p>
            <button
              onClick={onOpenNewNote}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#8a6828] to-[#c7983e] text-[#1c1409] font-serif font-bold text-xs shadow-md"
            >
              Write First Page
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {regularNotes.map((note) => (
              <NoteCard
                key={note.id}
                note={note}
                onSelect={onSelectNote}
                onTogglePin={onTogglePin}
                onDelete={onDeleteNote}
              />
            ))}
          </div>
        )}
      </section>

      {/* Compliant AdMob Banner Slot */}
      <section className="pt-4">
        <AdMobBanner placement="bottom-docked" />
      </section>
    </div>
  );
}
