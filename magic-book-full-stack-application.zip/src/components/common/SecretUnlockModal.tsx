"use client";

import React, { useEffect } from "react";
import { Sparkles, Flame, Eye, Film, ArrowRight } from "lucide-react";

interface SecretUnlockModalProps {
  isOpen: boolean;
  onProceed: () => void;
}

export function SecretUnlockModal({ isOpen, onProceed }: SecretUnlockModalProps) {
  useEffect(() => {
    if (isOpen) {
      const timer = setTimeout(() => {
        onProceed();
      }, 2200);
      return () => clearTimeout(timer);
    }
  }, [isOpen, onProceed]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in duration-300">
      <div className="relative max-w-sm w-full rounded-3xl bg-gradient-to-b from-[#241a12] via-[#1a120c] to-[#120c08] border border-[#d4af37]/60 shadow-[0_0_50px_rgba(212,175,55,0.4)] p-8 text-center text-[#fcf8f0] space-y-4 secret-aura">
        {/* Glow Mandala */}
        <div className="relative w-20 h-20 mx-auto flex items-center justify-center">
          <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-[#d4af37] to-[#8c671b] animate-ping opacity-30" />
          <div className="relative w-16 h-16 rounded-full bg-gradient-to-br from-[#f8d87b] via-[#cf9f3b] to-[#7c5b16] p-0.5 shadow-2xl flex items-center justify-center">
            <div className="w-full h-full bg-[#1e150d] rounded-full flex items-center justify-center">
              <Flame className="w-9 h-9 text-[#fadc82] animate-bounce" />
            </div>
          </div>
        </div>

        <div className="space-y-1.5">
          <span className="text-[11px] uppercase font-mono tracking-widest text-[#f5d88f] px-3 py-0.5 bg-[#d4af37]/20 rounded-full border border-[#d4af37]/40">
            Sacred Mantra Verified
          </span>
          <h2 className="font-serif text-2xl font-black tracking-tight text-[#fdf8f0]">
            SHIVAAY UNLOCKED
          </h2>
          <p className="text-xs text-[#d1c2b0] font-serif leading-relaxed">
            The secret chambers of the Magic Book have parted. Unveiling the Enchanted Cinema Library...
          </p>
        </div>

        <div className="pt-2">
          <button
            onClick={onProceed}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#c59c44] via-[#f0cf7e] to-[#b38833] text-[#191107] font-serif font-bold text-xs shadow-lg hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <span>Enter Cinema Realm</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}
