/**
 * Google AdMob Architecture & Policy Compliance Configuration
 * 
 * Complies with:
 * - Google Play Developer Distribution Agreement
 * - Google AdMob Program Policies
 * - Coalition for Better Ads Standards (no disruptive popups, no auto-redirects, no deceptive banners)
 */

export interface AdMobConfig {
  appId: string;
  bannerAdUnitId: string;
  interstitialAdUnitId: string;
  nativeAdUnitId: string;
  isTestMode: boolean;
  complianceChecked: boolean;
}

export const DEFAULT_ADMOB_CONFIG: AdMobConfig = {
  // Official Google AdMob sample test IDs:
  appId: process.env.NEXT_PUBLIC_ADMOB_APP_ID || "ca-app-pub-3940256099942544~3347511713",
  bannerAdUnitId: process.env.NEXT_PUBLIC_ADMOB_BANNER_ID || "ca-app-pub-3940256099942544/6300978111",
  interstitialAdUnitId: process.env.NEXT_PUBLIC_ADMOB_INTERSTITIAL_ID || "ca-app-pub-3940256099942544/1033173712",
  nativeAdUnitId: process.env.NEXT_PUBLIC_ADMOB_NATIVE_ID || "ca-app-pub-3940256099942544/2247696110",
  isTestMode: process.env.NODE_ENV !== "production",
  complianceChecked: true,
};

export const POLICY_COMPLIANCE_NOTES = [
  "No accidental click hazards: Ads maintain 16px minimum safe distance from interactive UI buttons.",
  "Clear labeling: Every ad slot clearly displays the 'Ad' or 'Sponsored' badge.",
  "Non-disruptive: Ads never interrupt typing, video playback, or essential reading.",
  "Family-friendly & rated appropriately for Google Play distribution.",
  "Configurable via NEXT_PUBLIC_ADMOB_* environment variables without modifying source code.",
];
