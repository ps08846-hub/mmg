import bcrypt from "bcryptjs";
import { db } from "./index";
import { users, categories, videos, notes } from "./schema";
import { eq } from "drizzle-orm";

export async function seedDatabase() {
  // Check if admin user exists
  const existingAdmin = await db.query.users.findFirst({
    where: eq(users.email, "admin@magicbook.com"),
  });

  if (!existingAdmin) {
    const passwordHash = await bcrypt.hash("MagicBook2025!", 10);
    await db.insert(users).values({
      email: "admin@magicbook.com",
      name: "Archivist Shivaay (Admin)",
      passwordHash,
      role: "admin",
      avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&q=80",
    });
  }

  // Check if categories exist
  const existingCategories = await db.query.categories.findMany();
  let categoryMap: Record<string, number> = {};

  if (existingCategories.length === 0) {
    const insertedCategories = await db
      .insert(categories)
      .values([
        {
          name: "Mythology & Epic",
          slug: "mythology-epic",
          description: "Ancient lore, legendary sagas, and divine epics.",
          icon: "Flame",
        },
        {
          name: "Sci-Fi & Universe",
          slug: "scifi-universe",
          description: "Futuristic explorations, cybernetic visions, and deep cosmos.",
          icon: "Rocket",
        },
        {
          name: "Animation & Arts",
          slug: "animation-arts",
          description: "Creative open animation, visual masterpieces, and digital artistry.",
          icon: "Sparkles",
        },
        {
          name: "Nature & Wonders",
          slug: "nature-wonders",
          description: "Serene landscapes, wildlife documentaries, and natural sanctuaries.",
          icon: "Compass",
        },
        {
          name: "Mysteries & Secrets",
          slug: "mysteries-secrets",
          description: "Enigmatic puzzles, forgotten grimoires, and surreal dimensions.",
          icon: "Eye",
        },
        {
          name: "Cinema & Films",
          slug: "cinema-films",
          description: "Independent cinema shorts and acclaimed open productions.",
          icon: "Film",
        },
      ])
      .returning();

    for (const cat of insertedCategories) {
      categoryMap[cat.slug] = cat.id;
    }
  } else {
    for (const cat of existingCategories) {
      categoryMap[cat.slug] = cat.id;
    }
  }

  // Check if videos exist
  const existingVideos = await db.query.videos.findMany();
  if (existingVideos.length === 0) {
    await db.insert(videos).values([
      {
        title: "Tears of Steel: Sci-Fi Chronicle",
        slug: "tears-of-steel",
        description:
          "Set in a dystopian future Amsterdam, a courageous cohort of warriors and scientists explore an ancient robotic anomaly in this acclaimed open-source sci-fi film (Blender Foundation / CC-BY).",
        categoryId: categoryMap["scifi-universe"] || 1,
        videoUrl:
          "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
        thumbnailUrl:
          "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=800&q=80",
        duration: "12:14",
        videoType: "movie",
        tags: JSON.stringify(["Sci-Fi", "VFX", "Action", "Blender Open"]),
        isFeatured: true,
        isPublished: true,
        views: 14200,
        rating: "4.9",
        releaseYear: 2024,
      },
      {
        title: "Sintel: The Dragon Quest",
        slug: "sintel-dragon-quest",
        description:
          "A solitary wanderer named Sintel bonds with an orphaned baby dragon and embarks on a perilous quest across snowy mountain peaks and forgotten ruins to save him. (Blender Foundation / CC-BY).",
        categoryId: categoryMap["mythology-epic"] || 1,
        videoUrl:
          "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
        thumbnailUrl:
          "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&q=80",
        duration: "14:48",
        videoType: "movie",
        tags: JSON.stringify(["Fantasy", "Epic", "Adventure", "Dragon"]),
        isFeatured: true,
        isPublished: true,
        views: 29500,
        rating: "5.0",
        releaseYear: 2024,
      },
      {
        title: "Big Buck Bunny: Forest Tales",
        slug: "big-buck-bunny",
        description:
          "A cheerful giant rabbit protects his woodland friends from playful forest bullies in this world-celebrated open-source animated adventure (Blender Foundation / CC-BY).",
        categoryId: categoryMap["animation-arts"] || 1,
        videoUrl:
          "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
        thumbnailUrl:
          "https://images.unsplash.com/photo-1579783902614-a3fb3927b675?w=800&q=80",
        duration: "9:56",
        videoType: "short",
        tags: JSON.stringify(["Animation", "Family", "Comedy", "Nature"]),
        isFeatured: true,
        isPublished: true,
        views: 38100,
        rating: "4.8",
        releaseYear: 2023,
      },
      {
        title: "The Himalayan Sanctuary: Sacred Peaks",
        slug: "himalayan-sanctuary",
        description:
          "An evocative visual meditation on the ancient spiritual peaks of the Himalayas, where mountain winds and timeless legends intertwine. Dedicated to Shivaay.",
        categoryId: categoryMap["mythology-epic"] || 1,
        videoUrl:
          "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4",
        thumbnailUrl:
          "https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=800&q=80",
        duration: "15:30",
        videoType: "documentary",
        tags: JSON.stringify(["Himalayas", "Sacred", "Shivaay", "Peace"]),
        isFeatured: true,
        isPublished: true,
        views: 18900,
        rating: "5.0",
        releaseYear: 2025,
      },
      {
        title: "Elephants Dream: Machine Heart",
        slug: "elephants-dream",
        description:
          "Two eccentric explorers navigate the surreal, shifting labyrinth of an incomprehensible mechanical world. The world's pioneering open-movie CGI production.",
        categoryId: categoryMap["mysteries-secrets"] || 1,
        videoUrl:
          "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
        thumbnailUrl:
          "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=800&q=80",
        duration: "10:53",
        videoType: "movie",
        tags: JSON.stringify(["Surreal", "Mystery", "Philosophy", "Classic"]),
        isFeatured: false,
        isPublished: true,
        views: 8750,
        rating: "4.7",
        releaseYear: 2022,
      },
      {
        title: "Cosmic Voyage: Echoes of Eternity",
        slug: "cosmic-voyage",
        description:
          "Venture deep into the cosmic tapestry, soaring past interstellar nebulae, stellar nurseries, and untouched alien horizons in high dynamic fidelity.",
        categoryId: categoryMap["scifi-universe"] || 1,
        videoUrl:
          "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
        thumbnailUrl:
          "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&q=80",
        duration: "18:20",
        videoType: "documentary",
        tags: JSON.stringify(["Cosmos", "Documentary", "Stars", "Astronomy"]),
        isFeatured: false,
        isPublished: true,
        views: 11200,
        rating: "4.8",
        releaseYear: 2025,
      },
      {
        title: "Wilderness Odyssey: Earth in Motion",
        slug: "wilderness-odyssey",
        description:
          "A sweeping visual symphony traversing misty temperate rainforests, raging alpine cascades, and quiet desert canyons at golden hour.",
        categoryId: categoryMap["nature-wonders"] || 1,
        videoUrl:
          "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
        thumbnailUrl:
          "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=800&q=80",
        duration: "16:45",
        videoType: "documentary",
        tags: JSON.stringify(["Nature", "Wildlife", "Cinematography", "Earth"]),
        isFeatured: false,
        isPublished: true,
        views: 9400,
        rating: "4.9",
        releaseYear: 2024,
      },
      {
        title: "Artisan Quill: The Lost Journal",
        slug: "artisan-quill",
        description:
          "An intimate glimpse into the ateliers of master bookbinders who hand-stitch parchment, press gold leaf bindings, and craft journals meant to guard sacred thoughts forever.",
        categoryId: categoryMap["mysteries-secrets"] || 1,
        videoUrl:
          "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4",
        thumbnailUrl:
          "https://images.unsplash.com/photo-1455390582262-044cdead277a?w=800&q=80",
        duration: "11:15",
        videoType: "short",
        tags: JSON.stringify(["Notebook", "Craft", "Calligraphy", "Artisan"]),
        isFeatured: false,
        isPublished: true,
        views: 7300,
        rating: "4.9",
        releaseYear: 2025,
      },
    ]);
  }

  // Check if starter notes exist
  const existingNotes = await db.query.notes.findMany();
  if (existingNotes.length === 0) {
    await db.insert(notes).values([
      {
        title: "Welcome to Your Magic Book ✨",
        content: `Welcome to Magic Book — your personal handwritten sanctuary.

Here, your thoughts flow onto authentic parchment pages. Whether you are capturing daily reflections, study thoughts, sketches of poetry, or clandestine blueprints, your words are kept safe and sacred.

🖋️ Quick Journal Tips:
1. Tap the "+ New Page" quill button to create a new page anytime.
2. Select your favorite paper texture (Ruled, Grid, Parchment, Blank).
3. Search through your thoughts instantly using the header search bar.
4. Pin important pages so they stay on your journal desk.

P.S. There is an ancient whispered legend among scribes... Typing a certain sacred mantra in the search bar might unlock a secret hidden realm. What was the name again? Something celestial... something like "SHIVAAY"... 🗝️`,
        paperStyle: "parchment",
        color: "amber",
        tags: JSON.stringify(["Journal", "Welcome", "Secrets"]),
        isPinned: true,
        isArchived: false,
      },
      {
        title: "Morning Routine & Mindful Stillness",
        content: `06:30 AM — Warm water with mountain lemon & honey.
06:45 AM — 15 minutes of Pranayama and quiet breathwork.
07:15 AM — Read 10 pages of philosophy by candlelight.
08:00 AM — Sketch today's 3 primary creative intentions:
  • Finish the manuscript outline
  • Walk 5 kilometers under the pines
  • Listen to deep stillness before dusk

"The mind is not a vessel to be filled, but a fire to be kindled."`,
        paperStyle: "ruled",
        color: "sky",
        tags: JSON.stringify(["Habits", "Morning", "Mindfulness"]),
        isPinned: true,
        isArchived: false,
      },
      {
        title: "Architectural Ideas for The Glass Library",
        content: `Drafting structural ideas for a high-altitude sanctuary:

[X] Vaulted timber arches with cedar aroma
[X] Hand-beaten copper lanterns hanging from iron chains
[ ] Floor-to-ceiling double-glazed bay windows facing north
[ ] Inlaid stone reading nooks with wool rugs

Notes on lighting: Use warm 2400K illumination. No harsh glare. Every desk must have its own brass reading lamp and leather blotter.`,
        paperStyle: "grid",
        color: "emerald",
        tags: JSON.stringify(["Architecture", "Design", "Vision"]),
        isPinned: false,
        isArchived: false,
      },
      {
        title: "Poetic Fragments on the Mountain Wind",
        content: `The snow does not ask where the wind travels.
It only follows the contours of the stone.
In quietude, the deepest answers arrive unannounced,
Like deer stepping onto the frost before the sun rises.`,
        paperStyle: "parchment",
        color: "rose",
        tags: JSON.stringify(["Poetry", "Nature", "Thoughts"]),
        isPinned: false,
        isArchived: false,
      },
    ]);
  }

  return { success: true };
}
