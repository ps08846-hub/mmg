export type AppMode = "notebook" | "shivaay" | "admin";

export type PaperStyle = "ruled" | "grid" | "blank" | "parchment" | "dark-scribe";

export type NoteColor = "amber" | "emerald" | "rose" | "sky" | "indigo" | "stone";

export type VideoType = "movie" | "short" | "documentary" | "series";

export interface NoteItem {
  id: number;
  userId?: number | null;
  guestSessionId?: string | null;
  title: string;
  content: string;
  paperStyle: PaperStyle;
  color: NoteColor;
  tags: string; // JSON array string
  isPinned: boolean;
  isArchived: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface CategoryItem {
  id: number;
  name: string;
  slug: string;
  description?: string | null;
  icon?: string | null;
  videoCount?: number;
  createdAt?: string;
}

export interface VideoItem {
  id: number;
  title: string;
  slug: string;
  description: string;
  categoryId?: number | null;
  category?: CategoryItem | null;
  videoUrl: string;
  thumbnailUrl: string;
  duration: string;
  videoType: VideoType;
  tags: string; // JSON array string
  isFeatured: boolean;
  isPublished: boolean;
  views: number;
  rating: string;
  releaseYear: number;
  createdAt: string;
  updatedAt: string;
}

export interface AdminUser {
  id: number;
  email: string;
  name: string;
  role: string;
}
