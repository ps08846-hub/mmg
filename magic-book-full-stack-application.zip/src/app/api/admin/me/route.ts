import { NextResponse } from "next/server";
import { getAdminSession } from "@/lib/auth";

export async function GET() {
  try {
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json({ success: false, user: null }, { status: 401 });
    }
    return NextResponse.json({ success: true, user: session });
  } catch (error) {
    console.error("Session check error:", error);
    return NextResponse.json({ success: false, user: null }, { status: 500 });
  }
}
