import { NextResponse } from "next/server";
import { db } from "@/db";
import { videos, notes, categories, users } from "@/db/schema";
import { count, sum, eq } from "drizzle-orm";
import { getAdminSession } from "@/lib/auth";

export async function GET() {
  try {
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    }

    const [videoCount] = await db.select({ val: count() }).from(videos);
    const [publishedCount] = await db
      .select({ val: count() })
      .from(videos)
      .where(eq(videos.isPublished, true));
    const [noteCount] = await db.select({ val: count() }).from(notes);
    const [categoryCount] = await db.select({ val: count() }).from(categories);
    const [totalViews] = await db.select({ val: sum(videos.views) }).from(videos);
    const [userCount] = await db.select({ val: count() }).from(users);

    return NextResponse.json({
      success: true,
      stats: {
        totalVideos: Number(videoCount.val),
        publishedVideos: Number(publishedCount.val),
        draftVideos: Number(videoCount.val) - Number(publishedCount.val),
        totalNotes: Number(noteCount.val),
        totalCategories: Number(categoryCount.val),
        totalViews: Number(totalViews.val || 0),
        totalUsers: Number(userCount.val),
      },
    });
  } catch (error) {
    console.error("Error getting admin stats:", error);
    return NextResponse.json({ success: false, error: "Failed to load stats" }, { status: 500 });
  }
}
