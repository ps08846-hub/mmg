import { NextResponse } from "next/server";
import { db } from "@/db";
import { categories, videos } from "@/db/schema";
import { eq, count } from "drizzle-orm";
import { getAdminSession } from "@/lib/auth";

export async function GET() {
  try {
    const allCategories = await db.query.categories.findMany();

    // Get video counts per category
    const videoCounts = await db
      .select({
        categoryId: videos.categoryId,
        count: count(videos.id),
      })
      .from(videos)
      .where(eq(videos.isPublished, true))
      .groupBy(videos.categoryId);

    const countMap: Record<number, number> = {};
    for (const row of videoCounts) {
      if (row.categoryId !== null) {
        countMap[row.categoryId] = Number(row.count);
      }
    }

    const categoriesWithCount = allCategories.map((cat) => ({
      ...cat,
      videoCount: countMap[cat.id] || 0,
    }));

    return NextResponse.json({ success: true, categories: categoriesWithCount });
  } catch (error) {
    console.error("Error fetching categories:", error);
    return NextResponse.json(
      { success: false, error: "Failed to fetch categories" },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json(
        { success: false, error: "Unauthorized. Admin access required." },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { name, slug, description, icon } = body;

    if (!name) {
      return NextResponse.json(
        { success: false, error: "Category name is required" },
        { status: 400 }
      );
    }

    const safeSlug =
      slug?.trim() ||
      name
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/(^-|-$)/g, "");

    const newCategory = await db
      .insert(categories)
      .values({
        name: name.trim(),
        slug: safeSlug,
        description: description?.trim() || "",
        icon: icon?.trim() || "Film",
      })
      .returning();

    return NextResponse.json({ success: true, category: newCategory[0] }, { status: 201 });
  } catch (error) {
    console.error("Error creating category:", error);
    return NextResponse.json(
      { success: false, error: error instanceof Error ? error.message : "Failed to create category" },
      { status: 500 }
    );
  }
}
