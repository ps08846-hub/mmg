import { NextResponse } from "next/server";
import { db } from "@/db";
import { notes } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const noteId = parseInt(id, 10);
    if (isNaN(noteId)) {
      return NextResponse.json({ success: false, error: "Invalid note ID" }, { status: 400 });
    }

    const note = await db.query.notes.findFirst({
      where: eq(notes.id, noteId),
    });

    if (!note) {
      return NextResponse.json({ success: false, error: "Note not found" }, { status: 404 });
    }

    return NextResponse.json({ success: true, note });
  } catch (error) {
    console.error("Error fetching note:", error);
    return NextResponse.json({ success: false, error: "Failed to fetch note" }, { status: 500 });
  }
}

export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const noteId = parseInt(id, 10);
    if (isNaN(noteId)) {
      return NextResponse.json({ success: false, error: "Invalid note ID" }, { status: 400 });
    }

    const body = await request.json();
    const { title, content, paperStyle, color, tags, isPinned, isArchived } = body;

    const updateData: Partial<typeof notes.$inferInsert> = {
      updatedAt: new Date(),
    };

    if (title !== undefined) updateData.title = String(title).trim();
    if (content !== undefined) updateData.content = String(content);
    if (paperStyle !== undefined) updateData.paperStyle = String(paperStyle);
    if (color !== undefined) updateData.color = String(color);
    if (tags !== undefined) {
      updateData.tags = Array.isArray(tags) ? JSON.stringify(tags) : typeof tags === "string" ? tags : "[]";
    }
    if (isPinned !== undefined) updateData.isPinned = Boolean(isPinned);
    if (isArchived !== undefined) updateData.isArchived = Boolean(isArchived);

    const updated = await db
      .update(notes)
      .set(updateData)
      .where(eq(notes.id, noteId))
      .returning();

    if (updated.length === 0) {
      return NextResponse.json({ success: false, error: "Note not found" }, { status: 404 });
    }

    return NextResponse.json({ success: true, note: updated[0] });
  } catch (error) {
    console.error("Error updating note:", error);
    return NextResponse.json({ success: false, error: "Failed to update note" }, { status: 500 });
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const noteId = parseInt(id, 10);
    if (isNaN(noteId)) {
      return NextResponse.json({ success: false, error: "Invalid note ID" }, { status: 400 });
    }

    const deleted = await db.delete(notes).where(eq(notes.id, noteId)).returning();
    if (deleted.length === 0) {
      return NextResponse.json({ success: false, error: "Note not found" }, { status: 404 });
    }

    return NextResponse.json({ success: true, message: "Note deleted successfully" });
  } catch (error) {
    console.error("Error deleting note:", error);
    return NextResponse.json({ success: false, error: "Failed to delete note" }, { status: 500 });
  }
}
