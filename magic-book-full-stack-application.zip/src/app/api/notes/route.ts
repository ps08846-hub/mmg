import { NextResponse } from "next/server";
import { db } from "@/db";
import { notes } from "@/db/schema";
import { desc, ilike, or, eq, and } from "drizzle-orm";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const q = searchParams.get("q")?.trim();
    const tag = searchParams.get("tag")?.trim();
    const paperStyle = searchParams.get("style")?.trim();
    const pinned = searchParams.get("pinned");

    const conditions = [];

    if (q) {
      conditions.push(
        or(
          ilike(notes.title, `%${q}%`),
          ilike(notes.content, `%${q}%`)
        )
      );
    }

    if (paperStyle && paperStyle !== "all") {
      conditions.push(eq(notes.paperStyle, paperStyle));
    }

    if (pinned === "true") {
      conditions.push(eq(notes.isPinned, true));
    }

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

    const allNotes = await db.query.notes.findMany({
      where: whereClause,
      orderBy: [desc(notes.isPinned), desc(notes.updatedAt)],
    });

    let filtered = allNotes;
    if (tag) {
      filtered = allNotes.filter((n) => {
        try {
          const tagsArray = JSON.parse(n.tags) as string[];
          return tagsArray.some((t) => t.toLowerCase() === tag.toLowerCase());
        } catch {
          return false;
        }
      });
    }

    return NextResponse.json({ success: true, notes: filtered });
  } catch (error) {
    console.error("Error fetching notes:", error);
    return NextResponse.json(
      { success: false, error: "Failed to fetch notes" },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { title, content, paperStyle, color, tags, isPinned } = body;

    if (!title || typeof title !== "string" || !title.trim()) {
      return NextResponse.json(
        { success: false, error: "Title is required" },
        { status: 400 }
      );
    }

    const newNote = await db
      .insert(notes)
      .values({
        title: title.trim(),
        content: typeof content === "string" ? content : "",
        paperStyle: paperStyle || "ruled",
        color: color || "amber",
        tags: Array.isArray(tags) ? JSON.stringify(tags) : typeof tags === "string" ? tags : "[]",
        isPinned: Boolean(isPinned),
        updatedAt: new Date(),
      })
      .returning();

    return NextResponse.json({ success: true, note: newNote[0] }, { status: 201 });
  } catch (error) {
    console.error("Error creating note:", error);
    return NextResponse.json(
      { success: false, error: "Failed to create note" },
      { status: 500 }
    );
  }
}
