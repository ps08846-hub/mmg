import { NextResponse } from "next/server";
import { db } from "@/db";
import { savedVideos } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { cookies } from "next/headers";

async function getOrCreateSessionId(): Promise<string> {
  const cookieStore = await cookies();
  let sessionId = cookieStore.get("magicbook_visitor")?.value;
  if (!sessionId) {
    sessionId = "guest_" + Math.random().toString(36).substring(2) + Date.now().toString(36);
    cookieStore.set("magicbook_visitor", sessionId, {
      httpOnly: false,
      sameSite: "lax",
      path: "/",
      maxAge: 60 * 60 * 24 * 365,
    });
  }
  return sessionId;
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    let sessionId = searchParams.get("sessionId");
    if (!sessionId) {
      sessionId = await getOrCreateSessionId();
    }

    const saved = await db.query.savedVideos.findMany({
      where: eq(savedVideos.sessionId, sessionId),
      with: {
        video: {
          with: {
            category: true,
          },
        },
      },
    });

    const videosList = saved
      .map((item) => item.video)
      .filter((v) => v !== null && v.isPublished);

    return NextResponse.json({ success: true, videos: videosList });
  } catch (error) {
    console.error("Error fetching saved videos:", error);
    return NextResponse.json(
      { success: false, error: "Failed to fetch saved videos" },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { videoId } = body;
    let { sessionId } = body;

    if (!videoId) {
      return NextResponse.json(
        { success: false, error: "videoId is required" },
        { status: 400 }
      );
    }

    if (!sessionId) {
      sessionId = await getOrCreateSessionId();
    }

    const numericVideoId = parseInt(String(videoId), 10);

    // Check if already saved
    const existing = await db.query.savedVideos.findFirst({
      where: and(
        eq(savedVideos.sessionId, sessionId),
        eq(savedVideos.videoId, numericVideoId)
      ),
    });

    if (existing) {
      // Toggle off / remove
      await db.delete(savedVideos).where(eq(savedVideos.id, existing.id));
      return NextResponse.json({ success: true, saved: false, message: "Removed from saved" });
    }

    await db.insert(savedVideos).values({
      sessionId,
      videoId: numericVideoId,
    });

    return NextResponse.json({ success: true, saved: true, message: "Saved to Watchlist" });
  } catch (error) {
    console.error("Error saving video:", error);
    return NextResponse.json(
      { success: false, error: "Failed to update saved videos" },
      { status: 500 }
    );
  }
}
