import { NextResponse } from "next/server";
import { db } from "@/db";
import { videos } from "@/db/schema";
import { eq, sql, ne, and } from "drizzle-orm";
import { getAdminSession } from "@/lib/auth";

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const videoId = parseInt(id, 10);

    const condition = isNaN(videoId) ? eq(videos.slug, id) : eq(videos.id, videoId);

    const video = await db.query.videos.findFirst({
      where: condition,
      with: {
        category: true,
      },
    });

    if (!video) {
      return NextResponse.json({ success: false, error: "Video not found" }, { status: 404 });
    }

    // Increment views safely
    await db
      .update(videos)
      .set({ views: sql`${videos.views} + 1` })
      .where(eq(videos.id, video.id));

    // Fetch related videos (same category or latest, excluding current)
    const related = await db.query.videos.findMany({
      where: and(
        eq(videos.isPublished, true),
        ne(videos.id, video.id),
        video.categoryId ? eq(videos.categoryId, video.categoryId) : undefined
      ),
      limit: 6,
      with: {
        category: true,
      },
    });

    return NextResponse.json({
      success: true,
      video: { ...video, views: video.views + 1 },
      related,
    });
  } catch (error) {
    console.error("Error fetching video:", error);
    return NextResponse.json({ success: false, error: "Failed to fetch video" }, { status: 500 });
  }
}

export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json(
        { success: false, error: "Unauthorized. Admin access required." },
        { status: 401 }
      );
    }

    const { id } = await params;
    const videoId = parseInt(id, 10);
    if (isNaN(videoId)) {
      return NextResponse.json({ success: false, error: "Invalid video ID" }, { status: 400 });
    }

    const body = await request.json();
    const {
      title,
      slug,
      description,
      categoryId,
      videoUrl,
      thumbnailUrl,
      duration,
      videoType,
      tags,
      isFeatured,
      isPublished,
      rating,
      releaseYear,
    } = body;

    const updateData: Partial<typeof videos.$inferInsert> = {
      updatedAt: new Date(),
    };

    if (title !== undefined) updateData.title = String(title).trim();
    if (slug !== undefined) updateData.slug = String(slug).trim();
    if (description !== undefined) updateData.description = String(description).trim();
    if (categoryId !== undefined) {
      updateData.categoryId = categoryId ? parseInt(String(categoryId), 10) : null;
    }
    if (videoUrl !== undefined) updateData.videoUrl = String(videoUrl).trim();
    if (thumbnailUrl !== undefined) updateData.thumbnailUrl = String(thumbnailUrl).trim();
    if (duration !== undefined) updateData.duration = String(duration).trim();
    if (videoType !== undefined) updateData.videoType = String(videoType);
    if (tags !== undefined) {
      updateData.tags = Array.isArray(tags) ? JSON.stringify(tags) : typeof tags === "string" ? tags : "[]";
    }
    if (isFeatured !== undefined) updateData.isFeatured = Boolean(isFeatured);
    if (isPublished !== undefined) updateData.isPublished = Boolean(isPublished);
    if (rating !== undefined) updateData.rating = String(rating);
    if (releaseYear !== undefined) updateData.releaseYear = parseInt(String(releaseYear), 10);

    const updated = await db
      .update(videos)
      .set(updateData)
      .where(eq(videos.id, videoId))
      .returning();

    if (updated.length === 0) {
      return NextResponse.json({ success: false, error: "Video not found" }, { status: 404 });
    }

    return NextResponse.json({ success: true, video: updated[0] });
  } catch (error) {
    console.error("Error updating video:", error);
    return NextResponse.json({ success: false, error: "Failed to update video" }, { status: 500 });
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json(
        { success: false, error: "Unauthorized. Admin access required." },
        { status: 401 }
      );
    }

    const { id } = await params;
    const videoId = parseInt(id, 10);
    if (isNaN(videoId)) {
      return NextResponse.json({ success: false, error: "Invalid video ID" }, { status: 400 });
    }

    const deleted = await db.delete(videos).where(eq(videos.id, videoId)).returning();
    if (deleted.length === 0) {
      return NextResponse.json({ success: false, error: "Video not found" }, { status: 404 });
    }

    return NextResponse.json({ success: true, message: "Video deleted successfully" });
  } catch (error) {
    console.error("Error deleting video:", error);
    return NextResponse.json({ success: false, error: "Failed to delete video" }, { status: 500 });
  }
}
