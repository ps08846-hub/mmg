import { NextResponse } from "next/server";
import { db } from "@/db";
import { videos, categories } from "@/db/schema";
import { desc, ilike, or, eq, and } from "drizzle-orm";
import { getAdminSession } from "@/lib/auth";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const q = searchParams.get("q")?.trim();
    const categorySlug = searchParams.get("category")?.trim();
    const videoType = searchParams.get("type")?.trim();
    const featured = searchParams.get("featured");
    const sort = searchParams.get("sort") || "latest"; // 'latest' | 'popular' | 'featured'
    const includeUnpublished = searchParams.get("includeUnpublished") === "true";

    const conditions = [];

    // Filter unpublished unless requested by admin
    if (!includeUnpublished) {
      conditions.push(eq(videos.isPublished, true));
    }

    if (q) {
      conditions.push(
        or(
          ilike(videos.title, `%${q}%`),
          ilike(videos.description, `%${q}%`),
          ilike(videos.tags, `%${q}%`)
        )
      );
    }

    if (videoType && videoType !== "all") {
      conditions.push(eq(videos.videoType, videoType));
    }

    if (featured === "true") {
      conditions.push(eq(videos.isFeatured, true));
    }

    // Category filter by slug if provided
    if (categorySlug && categorySlug !== "all") {
      const targetCategory = await db.query.categories.findFirst({
        where: eq(categories.slug, categorySlug),
      });
      if (targetCategory) {
        conditions.push(eq(videos.categoryId, targetCategory.id));
      } else {
        const catId = parseInt(categorySlug, 10);
        if (!isNaN(catId)) {
          conditions.push(eq(videos.categoryId, catId));
        }
      }
    }

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

    let orderBy = [desc(videos.createdAt)];
    if (sort === "popular") {
      orderBy = [desc(videos.views)];
    } else if (sort === "featured") {
      orderBy = [desc(videos.isFeatured), desc(videos.views)];
    }

    const videoList = await db.query.videos.findMany({
      where: whereClause,
      with: {
        category: true,
      },
      orderBy,
    });

    return NextResponse.json({ success: true, videos: videoList });
  } catch (error) {
    console.error("Error fetching videos:", error);
    return NextResponse.json(
      { success: false, error: "Failed to fetch videos" },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json(
        { success: false, error: "Unauthorized. Admin access required." },
        { status: 401 }
      );
    }

    const body = await request.json();
    const {
      title,
      slug,
      description,
      categoryId,
      videoUrl,
      thumbnailUrl,
      duration,
      videoType,
      tags,
      isFeatured,
      isPublished,
      releaseYear,
    } = body;

    if (!title || !videoUrl) {
      return NextResponse.json(
        { success: false, error: "Title and Video URL are required" },
        { status: 400 }
      );
    }

    const safeSlug =
      slug?.trim() ||
      title
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/(^-|-$)/g, "") +
        "-" +
        Math.random().toString(36).substring(2, 6);

    const newVideo = await db
      .insert(videos)
      .values({
        title: title.trim(),
        slug: safeSlug,
        description: description?.trim() || "",
        categoryId: categoryId ? parseInt(String(categoryId), 10) : null,
        videoUrl: videoUrl.trim(),
        thumbnailUrl:
          thumbnailUrl?.trim() ||
          "https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=800&q=80",
        duration: duration?.trim() || "10:00",
        videoType: videoType || "movie",
        tags: Array.isArray(tags) ? JSON.stringify(tags) : typeof tags === "string" ? tags : "[]",
        isFeatured: Boolean(isFeatured),
        isPublished: isPublished !== undefined ? Boolean(isPublished) : true,
        releaseYear: releaseYear ? parseInt(String(releaseYear), 10) : new Date().getFullYear(),
        views: 0,
        rating: "4.8",
      })
      .returning();

    return NextResponse.json({ success: true, video: newVideo[0] }, { status: 201 });
  } catch (error) {
    console.error("Error creating video:", error);
    return NextResponse.json(
      { success: false, error: error instanceof Error ? error.message : "Failed to create video" },
      { status: 500 }
    );
  }
}
